/**
 * Google-помощник для «Мастерской 3D».
 * - Раз в неделю берёт комиссии и тарифы логистики WB, пишет письмо об изменениях.
 * - Каждый день дописывает продажи и возвраты WB в лист «Продажи WB» (WB хранит их только 90 дней).
 * - Хранит копию данных приложения и показывает склад листами «Склад», «Материалы», «Журнал», «Касса», «Опт».
 * - 3-го числа присылает письмо с прогнозом налога НПД за прошлый месяц.
 * - Забирает еженедельные отчёты WB о реализации и считает «Итого к оплате» (лист «Выплаты WB»).
 * - Каждый час забирает заказы FBS (лист «Заказы FBS»), в 17:30 присылает письмо «Что печатать».
 *
 * Ключ WB хранится только в настройках этого скрипта (Свойства скрипта),
 * в таблицу и в приложение он не попадает.
 */

var API = 'https://common-api.wildberries.ru';
var STAT = 'https://statistics-api.wildberries.ru';
var FIN = 'https://finance-api.wildberries.ru';
var MP = 'https://marketplace-api.wildberries.ru';
var CONTENT = 'https://content-api.wildberries.ru';
var VERSION = 13;
var TZ = 'Europe/Moscow';
var SH = { comm: 'Комиссии', wh: 'Логистика', track: 'Мои предметы', hist: 'История', sales: 'Продажи WB',
  stock: 'Склад', mats: 'Материалы', log: 'Журнал', money: 'Касса', deals: 'Опт', pay: 'Выплаты WB', ord: 'Заказы FBS', fact: 'Факт по товарам', data: '_данные' };
var MODELS = { fbs: 'FBS (маркетплейс)', dbs: 'DBS (витрина)', edbs: 'DBS экспресс', fbw: 'FBW (склад WB)' };

/* ---------------- меню ---------------- */
function onOpen() {
  SpreadsheetApp.getUi().createMenu('WB тарифы')
    .addItem('1. Ввести ключ WB и запустить', 'menuSetToken')
    .addItem('Обновить сейчас', 'menuRefresh')
    .addItem('Загрузить продажи сейчас', 'menuSales')
    .addItem('Загрузить выплаты WB сейчас', 'menuPayouts')
    .addItem('Загрузить выплаты WB за всё время', 'menuPayoutsAll')
    .addItem('Налог за прошлый месяц', 'menuTax')
    .addItem('Загрузить заказы FBS сейчас', 'menuOrders')
    .addItem('Факт по товарам (отчёты WB)', 'menuFact')
    .addItem('Прислать план печати сейчас', 'menuPlan')
    .addItem('Резервная копия в Google Диск сейчас', 'menuBackup')
    .addItem('Проверить связь с WB', 'menuCheck')
    .addSeparator()
    .addItem('Показать ключ синхронизации', 'menuSyncKey')
    .addItem('Сбросить ключ синхронизации', 'menuSyncReset')
    .addToUi();
}

function menuSetToken() {
  var ui = SpreadsheetApp.getUi();
  var r = ui.prompt('Ключ WB', 'Вставьте ключ из кабинета WB (Настройки → Доступ к API: тип «Персональный», категории «Статистика» и «Финансы», только чтение):', ui.ButtonSet.OK_CANCEL);
  if (r.getSelectedButton() !== ui.Button.OK) return;
  var t = String(r.getResponseText() || '').trim();
  if (t.length < 20) { ui.alert('Ключ слишком короткий. Скопируйте его целиком.'); return; }
  PropertiesService.getScriptProperties().setProperty('WB_TOKEN', t);
  ensureSheets_();
  ensureTrigger_();
  try {
    var res = refresh();
    ui.alert('Готово', 'Загружено предметов: ' + res.subjects + ', складов: ' + res.warehouses +
      '.\nВключено: тарифы — по понедельникам в 9:00, продажи — каждый день в 6:00 (МСК).\n\n' +
      'Следующий шаг: Развернуть → Новое развертывание → Веб-приложение (см. инструкцию).', ui.ButtonSet.OK);
  } catch (e) {
    ui.alert('Ключ сохранён, но WB ответил ошибкой:\n' + e.message);
  }
}

function menuRefresh() {
  var ui = SpreadsheetApp.getUi();
  try {
    var res = refresh();
    ui.alert('Обновлено', 'Предметов: ' + res.subjects + ', складов: ' + res.warehouses +
      '.\nИзменений по вашим предметам: ' + res.changes + (res.changes ? ' (письмо отправлено).' : '.'), ui.ButtonSet.OK);
  } catch (e) { ui.alert('Ошибка: ' + e.message); }
}

function menuCheck() {
  var ui = SpreadsheetApp.getUi();
  var t = token_();
  var exp = tokenExpiry_(t);
  var msg = t ? 'Ключ сохранён.' : 'Ключ не введён.';
  if (exp) msg += '\nКлюч действует до ' + Utilities.formatDate(exp, TZ, 'dd.MM.yyyy') + '.';
  var last = setting_('updated');
  msg += '\nПоследнее обновление: ' + (last || 'ещё не было');
  msg += '\nВеб-приложение: ' + (ScriptApp.getService().getUrl() || 'ещё не развёрнуто');
  ui.alert('Проверка', msg, ui.ButtonSet.OK);
}

/* ---------------- загрузка из WB ---------------- */
function wbGet_(path, host) {
  var t = token_();
  if (!t) throw new Error('Не введён ключ WB. Меню «WB тарифы» → «1. Ввести ключ WB».');
  var r = UrlFetchApp.fetch((host || API) + path, { method: 'get', headers: { Authorization: t }, muteHttpExceptions: true });
  var code = r.getResponseCode();
  if (code === 401) throw new Error('WB не принял ключ (401). Возможно, срок ключа истёк — создайте новый и введите его через меню.');
  if (code === 403) throw new Error('У ключа WB нет доступа к этому разделу (403). Создайте ключ с категорией «Статистика».');
  if (code === 429) throw new Error('WB просит подождать (лимит запросов). Повторите через минуту.');
  if (code >= 300) throw new Error('WB ответил кодом ' + code + ': ' + r.getContentText().slice(0, 200));
  var txt = r.getContentText();
  if (code === 204 || !txt) return [];
  return JSON.parse(txt);
}

function wbPost_(path, body, host) {
  var t = token_();
  if (!t) throw new Error('Не введён ключ WB. Меню «WB тарифы» → «1. Ввести ключ WB».');
  var r = UrlFetchApp.fetch((host || FIN) + path, { method: 'post', contentType: 'application/json', payload: JSON.stringify(body),
    headers: { Authorization: t }, muteHttpExceptions: true });
  var code = r.getResponseCode(), txt = r.getContentText() || '';
  if (code === 204 || (code === 200 && !txt)) return [];
  if (code === 200) return JSON.parse(txt);
  var err = new Error('WB ответил кодом ' + code + ': ' + txt.slice(0, 200));
  err.code = code;
  if (code === 401) err.message = 'WB не принял ключ (401). Возможно, срок ключа истёк — создайте новый и введите его через меню.';
  if (code === 403 && /base token/i.test(txt)) { err.message = 'base'; }
  else if (code === 403) err.message = 'У ключа WB нет категории «Финансы». Создайте ключ с категориями «Статистика» и «Финансы» и введите его через меню «1. Ввести ключ WB».';
  if (code === 429) err.message = 'WB просит подождать (лимит запросов). Повторите позже.';
  throw err;
}

function refresh() {
  ensureSheets_();
  try { ensureTrigger_(); } catch (x) {}
  var today = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');
  var commJson = wbGet_('/api/v1/tariffs/commission?locale=ru');
  var boxJson = wbGet_('/api/v1/tariffs/box?date=' + today);

  var subjects = parseCommissions(commJson);
  var box = parseBox(boxJson);
  if (!subjects.length) throw new Error('WB вернул пустой список комиссий.');

  var ss = SpreadsheetApp.getActive();
  writeRows_(ss.getSheetByName(SH.comm),
    ['ID предмета', 'Предмет', 'Категория', 'FBS %', 'DBS %', 'DBS экспресс %', 'FBW %'],
    subjects.map(function (s) { return [s.id, s.name, s.parent, s.fbs, s.dbs, s.edbs, s.fbw]; }));
  writeRows_(ss.getSheetByName(SH.wh),
    ['Склад', 'Регион', 'FBS 1-й литр ₽', 'FBS доп. литр ₽', 'FBW 1-й литр ₽', 'FBW доп. литр ₽'],
    box.warehouses.map(function (w) { return [w.name, w.geo, w.fbs1, w.fbsL, w.fbw1, w.fbwL]; }));

  // сравнение с прошлой неделей по вашим предметам и складу
  var model = setting_('model') || 'fbs';
  var whName = setting_('warehouse') || '';
  var tracked = readTracked_();
  var prevWh = JSON.parse(setting_('whSnapshot') || 'null');
  var curWh = pickWarehouse(box.warehouses, whName);
  var diff = diffTariffs(tracked, subjects, model, prevWh, curWh);

  // обновить «Мои предметы» текущими значениями
  var bySubj = {};
  subjects.forEach(function (s) { bySubj[s.id] = s; });
  var trackSheet = ss.getSheetByName(SH.track);
  writeRows_(trackSheet, ['ID предмета', 'Предмет', 'Комиссия % (' + MODELS[model] + ')', 'Проверено'],
    tracked.map(function (t) {
      var s = bySubj[t.id];
      return [t.id, s ? s.name : t.name, s ? s[model] : '', today];
    }));
  if (curWh) setSetting_('whSnapshot', JSON.stringify(curWh));
  setSetting_('updated', new Date().toISOString());
  setSetting_('boxNext', box.dtNext || '');

  if (diff.length) {
    var hist = ss.getSheetByName(SH.hist);
    diff.forEach(function (d) { hist.appendRow([today, d.what, d.before, d.after]); });
    sendMail_('WB: изменились тарифы по вашим товарам',
      'Изменения на ' + Utilities.formatDate(new Date(), TZ, 'dd.MM.yyyy') + ':\n\n' +
      diff.map(function (d) { return '• ' + d.what + ': было ' + d.before + ', стало ' + d.after; }).join('\n') +
      '\n\nОткройте «Мастерскую 3D» → «Изделия» → «Тарифы WB», чтобы пересчитать цены.');
  }
  checkTokenExpiry_();
  return { subjects: subjects.length, warehouses: box.warehouses.length, changes: diff.length };
}

/* ---------------- чистые функции (проверяются отдельно) ---------------- */
function num_(v) {
  if (v === null || v === undefined || v === '' || v === '-') return null;
  var n = parseFloat(String(v).replace(/\s/g, '').replace(',', '.'));
  return isFinite(n) ? n : null;
}

function parseCommissions(json) {
  var rows = (json && (json.report || json.data || json.response && json.response.report)) || [];
  return rows.map(function (r) {
    return {
      id: r.subjectID, name: r.subjectName || '', parent: r.parentName || '',
      fbs: num_(r.kgvpMarketplace), dbs: num_(r.kgvpSupplier),
      edbs: num_(r.kgvpSupplierExpress), fbw: num_(r.paidStorageKgvp)
    };
  }).filter(function (s) { return s.id; });
}

function parseBox(json) {
  var d = (json && json.response && json.response.data) || (json && json.data) || {};
  var list = d.warehouseList || [];
  return {
    dtNext: d.dtNextBox || '',
    warehouses: list.map(function (w) {
      var fbw1 = num_(w.boxDeliveryBase), fbwL = num_(w.boxDeliveryLiter);
      var mb1 = num_(w.boxDeliveryMarketplaceBase), mbL = num_(w.boxDeliveryMarketplaceLiter);
      return {
        name: w.warehouseName || '', geo: w.geoName || '',
        fbs1: mb1 !== null ? mb1 : fbw1, fbsL: mbL !== null ? mbL : fbwL,
        fbw1: fbw1, fbwL: fbwL
      };
    }).filter(function (w) { return w.name; })
  };
}

function pickWarehouse(list, name) {
  if (!list || !list.length) return null;
  var w = null;
  if (name) w = list.filter(function (x) { return x.name === name; })[0];
  if (!w) w = list.filter(function (x) { return /маркетплейс/i.test(x.name); })[0];
  return w || list[0];
}

function diffTariffs(tracked, subjects, model, prevWh, curWh) {
  var out = [], by = {};
  subjects.forEach(function (s) { by[s.id] = s; });
  tracked.forEach(function (t) {
    var s = by[t.id];
    if (!s) return;
    var now = s[model];
    if (t.last !== null && t.last !== undefined && t.last !== '' && now !== null && Number(t.last) !== Number(now)) {
      out.push({ what: 'Комиссия «' + s.name + '»', before: t.last + '%', after: now + '%' });
    }
  });
  if (prevWh && curWh && prevWh.name === curWh.name) {
    if (prevWh.fbs1 !== curWh.fbs1) out.push({ what: 'Логистика, 1-й литр (' + curWh.name + ')', before: prevWh.fbs1 + ' ₽', after: curWh.fbs1 + ' ₽' });
    if (prevWh.fbsL !== curWh.fbsL) out.push({ what: 'Логистика, доп. литр (' + curWh.name + ')', before: prevWh.fbsL + ' ₽', after: curWh.fbsL + ' ₽' });
  }
  return out;
}

function buildPayload(subjects, warehouses, updated, model, warehouse) {
  return {
    ok: true, v: 1, updated: updated, model: model, warehouse: warehouse,
    cols: ['id', 'name', 'parent', 'fbs', 'dbs', 'edbs', 'fbw'],
    subjects: subjects.map(function (s) { return [s.id, s.name, s.parent, s.fbs, s.dbs, s.edbs, s.fbw]; }),
    warehouses: warehouses
  };
}

/* ---------------- выдача данных приложению ---------------- */
function doGet(e) {
  var p = (e && e.parameter) || {};
  if (p.action) {
    try { return json_(privateGet_(p)); } catch (err) { return json_({ ok: false, error: err.message }); }
  }
  try {
    ensureSheets_();
    if (p.model && MODELS[p.model]) setSetting_('model', p.model);
    if (p.wh !== undefined && p.wh !== '') setSetting_('warehouse', String(p.wh).slice(0, 100));
    if (p.track) saveTracked_(String(p.track));
    var ss = SpreadsheetApp.getActive();
    var subjects = readRows_(ss.getSheetByName(SH.comm)).map(function (r) {
      return { id: r[0], name: r[1], parent: r[2], fbs: num_(r[3]), dbs: num_(r[4]), edbs: num_(r[5]), fbw: num_(r[6]) };
    });
    var warehouses = readRows_(ss.getSheetByName(SH.wh)).map(function (r) {
      return { name: r[0], geo: r[1], fbs1: num_(r[2]), fbsL: num_(r[3]), fbw1: num_(r[4]), fbwL: num_(r[5]) };
    });
    if (!subjects.length) return json_({ ok: false, error: 'В таблице ещё нет данных. Запустите «WB тарифы → Обновить сейчас».' });
    return json_(buildPayload(subjects, warehouses, setting_('updated'), setting_('model') || 'fbs', setting_('warehouse') || ''));
  } catch (err) {
    return json_({ ok: false, error: err.message });
  }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------------- служебное ---------------- */
function token_() { return PropertiesService.getScriptProperties().getProperty('WB_TOKEN') || ''; }

function tokenExpiry_(t) {
  try {
    var part = String(t).split('.')[1];
    if (!part) return null;
    while (part.length % 4) part += '=';
    var data = JSON.parse(Utilities.newBlob(Utilities.base64DecodeWebSafe(part)).getDataAsString());
    return data.exp ? new Date(data.exp * 1000) : null;
  } catch (e) { return null; }
}

function checkTokenExpiry_() {
  var exp = tokenExpiry_(token_());
  if (!exp) return;
  var days = Math.floor((exp - new Date()) / 86400000);
  if (days <= 14) {
    sendMail_('WB: ключ API скоро закончится',
      'Ключ WB для обновления тарифов действует ещё ' + Math.max(0, days) + ' дн. (до ' +
      Utilities.formatDate(exp, TZ, 'dd.MM.yyyy') + ').\n\nСоздайте новый ключ в кабинете WB (Настройки → Доступ к API, категория «Тарифы») ' +
      'и введите его в таблице: меню «WB тарифы» → «1. Ввести ключ WB».');
  }
}

function sendMail_(subject, body) {
  var to = Session.getEffectiveUser().getEmail();
  if (to) MailApp.sendEmail(to, subject, body);
}

function ensureSheets_() {
  var ss = SpreadsheetApp.getActive();
  [SH.comm, SH.wh, SH.track, SH.hist, SH.sales].forEach(function (n) {
    if (!ss.getSheetByName(n)) {
      var s = ss.insertSheet(n);
      if (n === SH.hist) s.appendRow(['Дата', 'Что', 'Было', 'Стало']);
      s.setFrozenRows(1);
    }
  });
}

function ensureTrigger_() {
  var names = ScriptApp.getProjectTriggers().map(function (t) { return t.getHandlerFunction(); });
  if (names.indexOf('weeklyRun') < 0) ScriptApp.newTrigger('weeklyRun').timeBased().onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(9).inTimezone(TZ).create();
  if (names.indexOf('dailyRun') < 0) ScriptApp.newTrigger('dailyRun').timeBased().everyDays(1).atHour(6).inTimezone(TZ).create();
  if (names.indexOf('ordersRun') < 0) ScriptApp.newTrigger('ordersRun').timeBased().everyHours(1).create();
  if (names.indexOf('printPlanRun') < 0) ScriptApp.newTrigger('printPlanRun').timeBased().everyDays(1).atHour(17).nearMinute(30).inTimezone(TZ).create();
  if (names.indexOf('monthlyRun') < 0) ScriptApp.newTrigger('monthlyRun').timeBased().onMonthDay(3).atHour(9).inTimezone(TZ).create();
}

function dailyRun() {
  try { syncPayouts(); } catch (x) {}
  try { if (setting_('payMode') === 'exact' && Date.now() - (Date.parse(setting_('factAt')) || 0) > 6 * 86400000) syncFact(); } catch (x) { setSetting_('factErr', x.message); }
  try { syncSales(); }
  catch (e) {
    var n = Number(setting_('salesErr') || 0) + 1;
    setSetting_('salesErr', n);
    if (n === 2) sendMail_('WB: не удаётся загрузить продажи', 'Ежедневная загрузка продаж не прошла два раза подряд:\n' + e.message);
  }
}

function weeklyRun() {
  try { backupRun(); } catch (x) { setSetting_('backupErr', x.message); }
  try { refresh(); }
  catch (e) { sendMail_('WB: не удалось обновить тарифы', 'Еженедельное обновление не прошло:\n' + e.message); }
}

function writeRows_(sheet, header, rows) {
  sheet.clearContents();
  sheet.getRange(1, 1, 1, header.length).setValues([header]).setFontWeight('bold');
  if (rows.length) sheet.getRange(2, 1, rows.length, header.length).setValues(rows.map(function (r) {
    return r.map(function (v) { return v === null || v === undefined ? '' : v; });
  }));
}

function readRows_(sheet) {
  if (!sheet || sheet.getLastRow() < 2) return [];
  return sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).getValues();
}

function readTracked_() {
  var ss = SpreadsheetApp.getActive();
  return readRows_(ss.getSheetByName(SH.track)).map(function (r) {
    return { id: Number(r[0]), name: r[1], last: r[2] === '' ? null : Number(r[2]) };
  }).filter(function (t) { return t.id; });
}

function saveTracked_(csv) {
  var ids = csv.split(',').map(function (x) { return Number(x); }).filter(function (x) { return x > 0; }).slice(0, 500);
  if (!ids.length) return;
  var ss = SpreadsheetApp.getActive();
  var model = setting_('model') || 'fbs';
  var old = {};
  readTracked_().forEach(function (t) { old[t.id] = t; });
  var by = {};
  readRows_(ss.getSheetByName(SH.comm)).forEach(function (r) { by[Number(r[0])] = r; });
  var col = { fbs: 3, dbs: 4, edbs: 5, fbw: 6 }[model];
  var today = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');
  writeRows_(ss.getSheetByName(SH.track), ['ID предмета', 'Предмет', 'Комиссия % (' + MODELS[model] + ')', 'Проверено'],
    ids.map(function (id) {
      if (old[id]) return [id, old[id].name, old[id].last === null ? '' : old[id].last, today];
      var r = by[id];
      return [id, r ? r[1] : '', r ? r[col] : '', today];
    }));
}

function setting_(key) {
  return PropertiesService.getScriptProperties().getProperty('S_' + key) || '';
}

function setSetting_(key, val) {
  PropertiesService.getScriptProperties().setProperty('S_' + key, String(val));
}

/* ================= продажи WB ================= */
var SALES_HEAD = ['ID продажи', 'Тип', 'Дата', 'Месяц', 'Артикул WB', 'Артикул продавца', 'Предмет',
  'Цена после скидки продавца', 'К перечислению', 'Цена для покупателя', 'Склад', 'Изменено WB'];

function menuSales() {
  var ui = SpreadsheetApp.getUi();
  try {
    ensureTrigger_();
    var r = syncSales();
    ui.alert('Продажи', 'Получено строк от WB: ' + r.got + ', новых: ' + r.added + ', обновлено: ' + r.updated +
      '.\nВсего в таблице: ' + r.total + '.', ui.ButtonSet.OK);
  } catch (e) { ui.alert('Ошибка: ' + e.message); }
}

function syncSales() {
  ensureSheets_();
  var from = setting_('salesFrom');
  if (!from) from = Utilities.formatDate(new Date(Date.now() - 89 * 86400000), TZ, "yyyy-MM-dd'T'00:00:00");
  var sheet = SpreadsheetApp.getActive().getSheetByName(SH.sales);
  sheet.getRange('C:D').setNumberFormat('@');
  sheet.getRange('L:L').setNumberFormat('@');
  var rows = readRows_(sheet), idx = {};
  rows.forEach(function (r, i) { idx[r[0]] = i; });
  var got = 0, added = 0, updated = 0, last = from;
  for (var page = 0; page < 3; page++) {
    if (page) Utilities.sleep(61000);
    var list = wbGet_('/api/v1/supplier/sales?dateFrom=' + encodeURIComponent(last), STAT) || [];
    if (!list.length) break;
    got += list.length;
    list.forEach(function (x) {
      var row = saleRow(x);
      if (!row) return;
      if (idx[row[0]] !== undefined) { rows[idx[row[0]]] = row; updated++; }
      else { idx[row[0]] = rows.length; rows.push(row); added++; }
    });
    last = list[list.length - 1].lastChangeDate || last;
    if (list.length < 75000) break;
  }
  rows.sort(function (a, b) { return String(a[2]) < String(b[2]) ? -1 : String(a[2]) > String(b[2]) ? 1 : 0; });
  writeRows_(sheet, SALES_HEAD, rows);
  setSetting_('salesFrom', last);
  setSetting_('salesAt', new Date().toISOString());
  setSetting_('salesErr', 0);
  return { got: got, added: added, updated: updated, total: rows.length };
}

function saleRow(x) {
  if (!x || !x.saleID) return null;
  var ret = String(x.saleID).charAt(0) === 'R';
  var date = String(x.date || '').slice(0, 10);
  var a = function (v) { var n = Number(v) || 0; return Math.abs(n); };
  return [String(x.saleID), ret ? 'Возврат' : 'Продажа', date, date.slice(0, 7), Number(x.nmId) || '',
    String(x.supplierArticle || ''), String(x.subject || ''), a(x.priceWithDisc), a(x.forPay), a(x.finishedPrice),
    String(x.warehouseName || ''), String(x.lastChangeDate || '')];
}

function salesSummary(rows, months) {
  var keep = {}, out = {};
  (months || []).forEach(function (m) { keep[m] = 1; });
  rows.forEach(function (r) {
    var m = String(r[3]); if (months && !keep[m]) return;
    var k = m + '|' + r[4];
    var o = out[k] || (out[k] = { m: m, nm: r[4], art: r[5], subj: r[6], n: 0, r: 0, rev: 0, pay: 0, fin: 0 });
    var sign = r[1] === 'Возврат' ? -1 : 1;
    if (sign > 0) o.n++; else o.r++;
    o.rev += sign * Number(r[7] || 0); o.pay += sign * Number(r[8] || 0); o.fin += sign * Number(r[9] || 0);
  });
  return Object.keys(out).map(function (k) {
    var o = out[k]; o.rev = Math.round(o.rev * 100) / 100; o.pay = Math.round(o.pay * 100) / 100; o.fin = Math.round(o.fin * 100) / 100; return o;
  }).sort(function (a, b) { return a.m < b.m ? 1 : a.m > b.m ? -1 : b.rev - a.rev; });
}

function lastMonths_(n) {
  var out = [], d = new Date();
  for (var i = 0; i < n; i++) {
    var x = new Date(d.getFullYear(), d.getMonth() - i, 1);
    out.push(Utilities.formatDate(x, TZ, 'yyyy-MM'));
  }
  return out;
}

/* ================= синхронизация приложения ================= */
/* Ключ создаёт сам сервер (таблица). Приложение не может задать его первым — его нужно ввести вручную. */
function syncKey_() {
  var k = setting_('syncKey');
  if (!k) { k = Utilities.getUuid().replace(/-/g, '').slice(0, 15).replace(/(.{5})(?!$)/g, '$1-'); setSetting_('syncKey', k); }
  return k;
}

function menuSyncKey() {
  SpreadsheetApp.getUi().alert('Ключ синхронизации', 'Ключ: ' + syncKey_() +
    '\n\nВведите его в приложении: «Ещё» → «Синхронизация» → «Включить».', SpreadsheetApp.getUi().ButtonSet.OK);
}

function menuSyncReset() {
  var ui = SpreadsheetApp.getUi();
  var r = ui.alert('Сбросить ключ?', 'Телефоны перестанут сохранять данные, пока синхронизацию не включат заново. Данные в таблице останутся.', ui.ButtonSet.OK_CANCEL);
  if (r !== ui.Button.OK) return;
  setSetting_('syncKey', '');
  ui.alert('Ключ сброшен. Новый ключ: ' + syncKey_() + '\n\nВведите его в приложении: «Ещё» → «Синхронизация» → «Включить».');
}

function checkKey_(key) {
  if (!key || String(key) !== syncKey_()) throw new Error('wrong_key');
  return true;
}

function privateGet_(p) {
  if (p.action === 'ping') return { ok: true, v: VERSION, sync: Number(setting_('rev') || 0) > 0, serverKey: true };
  checkKey_(p.key);
  if (p.action === 'meta') return { ok: true, v: VERSION, rev: Number(setting_('rev') || 0), device: setting_('device'), at: setting_('pushedAt') };
  if (p.action === 'pull') {
    var st = readState_();
    if (!st) return { ok: false, error: 'В таблице ещё нет сохранённых данных.' };
    return { ok: true, rev: Number(setting_('rev') || 0), device: setting_('device'), state: st };
  }
  if (p.action === 'fact') {
    var fl = Utilities.formatDate(new Date(Date.now() - (Number(p.days) || 120) * 86400000), TZ, 'yyyy-MM-dd');
    return { ok: true, at: setting_('factAt'), err: setting_('factErr'), rows: readRows_(SpreadsheetApp.getActive().getSheetByName(SH.fact) || null)
      .filter(function (r) { return String(r[2]) >= fl; })
      .map(function (r) { return { rep: r[0], from: String(r[1]), to: String(r[2]), nm: Number(r[3]) || 0, art: String(r[4] || ''), sold: +r[5] || 0, ret: +r[6] || 0,
        dlv: +r[7] || 0, back: +r[8] || 0, rev: +r[9] || 0, pay: +r[10] || 0, log: +r[11] || 0, stor: +r[12] || 0, acc: +r[13] || 0, pen: +r[14] || 0 }; }) };
  }
  if (p.action === 'orders') {
    if (ordersEnabled_() && Date.now() - (Date.parse(setting_('ordAt')) || 0) > 5 * 60000) {
      try { syncOrders(); } catch (e) { setSetting_('ordErr', e.message); }
    }
    var lim = Date.now() - 62 * 86400000;
    return { ok: true, at: setting_('ordAt'), err: setting_('ordErr'), rows: readRows_(SpreadsheetApp.getActive().getSheetByName(SH.ord) || null)
      .filter(function (r) { return new Date(String(r[1])).getTime() >= lim; })
      .map(function (r) { return { id: Number(r[0]), at: String(r[1]), nm: Number(r[2]) || 0, art: String(r[3] || ''), price: Number(r[4]) || 0, sup: String(r[5] || ''), wb: String(r[6] || '') }; }) };
  }
  if (p.action === 'payouts') {
    var pr = readRows_(SpreadsheetApp.getActive().getSheetByName(SH.pay)).slice(-400);
    return { ok: true, at: setting_('payAt'), mode: setting_('payMode') || 'exact', rows: pr.map(function (r) {
      return { id: r[0], from: String(r[1]), to: String(r[2]), goods: Number(r[3]) || 0, log: Number(r[4]) || 0, storage: Number(r[5]) || 0,
        acc: Number(r[6]) || 0, pen: Number(r[7]) || 0, ded: Number(r[8]) || 0, add: Number(r[9]) || 0, total: Number(r[10]) || 0 };
    }) };
  }
  if (p.action === 'sales') {
    var n = Math.min(24, Math.max(1, Number(p.months) || 13));
    var rows = readRows_(SpreadsheetApp.getActive().getSheetByName(SH.sales));
    return { ok: true, at: setting_('salesAt'), from: setting_('salesFrom'), months: lastMonths_(n), rows: salesSummary(rows, lastMonths_(n)) };
  }
  throw new Error('Неизвестное действие');
}

function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    var body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (String(body.action || '').indexOf('fbs') === 0) { checkKey_(body.key); return json_(fbsAction(body)); }
    if (body.action === 'wbCards' || body.action === 'wbPhoto') { checkKey_(body.key); return json_(cardsAction(body)); }
    if (body.action !== 'push') throw new Error('Неизвестное действие');
    checkKey_(body.key);
    if (typeof body.state !== 'string' || body.state.length < 10) throw new Error('Пустые данные');
    var prev = Number(setting_('rev') || 0);
    if (!body.force && prev > Number(body.base || 0) && setting_('device') !== String(body.device)) {
      return json_({ ok: false, error: 'conflict', rev: prev, device: setting_('device'), at: setting_('pushedAt') });
    }
    writeState_(body.state);
    if (body.tables) writeTables_(body.tables);
    setSetting_('rev', Number(body.rev) || Date.now());
    setSetting_('device', String(body.device || ''));
    setSetting_('pushedAt', new Date().toISOString());
    return json_({ ok: true, rev: Number(setting_('rev')) });
  } catch (err) {
    return json_({ ok: false, error: err.message });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

var CHUNK = 45000;
function writeState_(str) {
  var ss = SpreadsheetApp.getActive();
  var sh = ss.getSheetByName(SH.data) || ss.insertSheet(SH.data);
  try { sh.hideSheet(); } catch (x) {}
  sh.clearContents();
  var parts = [];
  for (var i = 0; i < str.length; i += CHUNK) parts.push([str.slice(i, i + CHUNK)]);
  sh.getRange(1, 1, parts.length, 1).setNumberFormat('@').setValues(parts);
}

function readState_() {
  var sh = SpreadsheetApp.getActive().getSheetByName(SH.data);
  if (!sh || sh.getLastRow() < 1) return '';
  return sh.getRange(1, 1, sh.getLastRow(), 1).getValues().map(function (r) { return String(r[0]); }).join('');
}

function writeTables_(t) {
  var ss = SpreadsheetApp.getActive();
  [[SH.stock, t.stock], [SH.mats, t.mats], [SH.log, t.log], [SH.money, t.money], [SH.deals, t.deals]].forEach(function (pair) {
    var tb = pair[1];
    if (!tb || !tb.head || !tb.rows) return;
    var sh = ss.getSheetByName(pair[0]);
    if (!sh) { sh = ss.insertSheet(pair[0]); sh.setFrozenRows(1); }
    writeRows_(sh, tb.head, tb.rows.map(function (r) { return r.slice(0, tb.head.length); }));
  });
}

/* ================= налог НПД ================= */
var MONTHS_GEN = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
var MONTHS_NOM = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'];

function prevMonthKey_() {
  var d = new Date(); var x = new Date(d.getFullYear(), d.getMonth() - 1, 1);
  return Utilities.formatDate(x, TZ, 'yyyy-MM');
}

/** Прогноз налога за месяц m ('yyyy-MM'): продажи WB из листа + опт и вычет из данных приложения. */
function taxForMonth(m, salesRows, state) {
  var wb = 0;
  salesRows.forEach(function (r) {
    if (String(r[3]) !== m) return;
    wb += (r[1] === 'Возврат' ? -1 : 1) * Number(r[7] || 0);
  });
  var b4o = 0, b6 = 0, b0 = 0, paid = null, bonus = 0;
  if (state) {
    (state.deals || []).forEach(function (d) {
      var dm = Utilities.formatDate(new Date(d.t), TZ, 'yyyy-MM');
      if (dm !== m) return;
      if (d.tax === 0.06) b6 += d.sum; else if (d.tax === 0.04) b4o += d.sum; else b0 += d.sum;
    });
    (state.money || []).forEach(function (x) {
      if (!x.taxRate || String(x.ref || '').indexOf('hist:m') !== 0) return;
      if (Utilities.formatDate(new Date(x.t), TZ, 'yyyy-MM') !== m) return;
      if (x.taxRate === 0.06) b6 += Number(x.rev) || 0; else if (x.taxRate === 0.04) b4o += Number(x.rev) || 0;
    });
    var tx = state.tax || {};
    bonus = Number(tx.bonus) > 0 ? Number(tx.bonus) : 0;
    paid = tx.paid && tx.paid[m] ? tx.paid[m] : null;
  }
  var b4 = wb + b4o, gross = b4 * 0.04 + b6 * 0.06, used = Math.min(bonus, b4 * 0.01 + b6 * 0.02);
  var r2 = function (v) { return Math.round(v * 100) / 100; };
  return { m: m, wb: r2(wb), b4o: r2(b4o), b6: r2(b6), b0: r2(b0), gross: r2(gross), bonus: r2(used), tax: r2(Math.max(0, gross - used)), paid: paid };
}

function taxText_(t) {
  var p = t.m.split('-'), mi = Number(p[1]) - 1, ni = (mi + 1) % 12;
  var f = function (v) { return String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ₽'; };
  var lines = ['Налог НПД за ' + MONTHS_NOM[mi] + ' ' + p[0] + ' ≈ ' + f(t.tax), '',
    '• Продажи WB (4%): ' + f(t.wb)];
  if (t.b4o) lines.push('• Опт частным лицам (4%): ' + f(t.b4o));
  if (t.b6) lines.push('• Опт ИП и организациям (6%): ' + f(t.b6));
  if (t.b0) lines.push('• Опт без налога: ' + f(t.b0));
  lines.push('• Налог по ставкам: ' + f(t.gross));
  if (t.bonus) lines.push('• Вычет: −' + f(t.bonus));
  lines.push('', 'ФНС покажет точную сумму в «Мой налог» до 12 ' + MONTHS_GEN[ni] + '. Оплатить до 28 ' + MONTHS_GEN[ni] + '.',
    'После оплаты отметьте её в приложении: «Деньги» → «Налоги» → «Отметить оплату».');
  return lines.join('\n');
}

function readStateObj_() {
  try { var s = readState_(); return s ? JSON.parse(s) : null; } catch (e) { return null; }
}

function monthlyRun() {
  try {
    try { syncSales(); } catch (x) {}
    var m = prevMonthKey_();
    var t = taxForMonth(m, readRows_(SpreadsheetApp.getActive().getSheetByName(SH.sales)), readStateObj_());
    if (t.paid || !(t.tax > 0)) return;
    sendMail_('Налог НПД за ' + MONTHS_NOM[Number(m.split('-')[1]) - 1] + ': ≈ ' + Math.round(t.tax) + ' ₽', taxText_(t));
  } catch (e) { sendMail_('Не удалось посчитать налог', e.message); }
}

function menuTax() {
  var m = prevMonthKey_();
  ensureTrigger_();
  var t = taxForMonth(m, readRows_(SpreadsheetApp.getActive().getSheetByName(SH.sales)), readStateObj_());
  SpreadsheetApp.getUi().alert('Налог', taxText_(t), SpreadsheetApp.getUi().ButtonSet.OK);
}

/* ================= выплаты WB (отчёт о реализации) ================= */
var PAY_HEAD = ['№ отчёта', 'С', 'По', 'К перечислению за товар', 'Логистика', 'Хранение', 'Платная приёмка', 'Штрафы', 'Удержания', 'Доплаты', 'Итого к оплате'];

function menuPayouts() {
  var ui = SpreadsheetApp.getUi();
  try {
    ensureTrigger_();
    var r = syncPayouts();
    ui.alert('Выплаты WB', 'Еженедельных отчётов: ' + r.reports + '.\n' + (r.mode === 'estimate' ? 'Суммы посчитаны по детализации (ключ «Базовый»). ' : '') +
      'Сверьте «Итого к оплате» на листе «Выплаты WB» с кабинетом WB (Финансовые отчёты).', ui.ButtonSet.OK);
  } catch (e) { ui.alert('Ошибка: ' + e.message); }
}

/** Список отчётов (новый метод): «Итого к оплате» берётся готовым из WB. */
function payoutListSummary(list) {
  var n = function (v) { var x = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(x) ? Math.round(x * 100) / 100 : 0; };
  return (list || []).filter(function (x) { return x && x.reportId; }).map(function (x) {
    return { id: x.reportId, from: String(x.dateFrom || '').slice(0, 10), to: String(x.dateTo || '').slice(0, 10),
      goods: n(x.forPaySum), log: n(x.deliveryServiceSum), storage: n(x.paidStorageSum), acc: n(x.paidAcceptanceSum),
      pen: n(x.penaltySum), ded: n(x.deductionSum), add: n(x.additionalPaymentSum), total: n(x.bankPaymentSum) };
  }).sort(function (a, b) { return a.to < b.to ? -1 : a.to > b.to ? 1 : 0; });
}

/** Детализация (новый метод, camelCase): оценка «Итого к оплате», если список отчётов недоступен. */
function payoutSummary(rows) {
  var by = {};
  var n = function (v) { var x = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(x) ? x : 0; };
  rows.forEach(function (x) {
    var id = x.reportId || x.realizationreport_id; if (!id) return;
    var o = by[id] || (by[id] = { id: id, from: String(x.dateFrom || x.date_from || '').slice(0, 10), to: String(x.dateTo || x.date_to || '').slice(0, 10),
      goods: 0, log: 0, storage: 0, acc: 0, pen: 0, ded: 0, add: 0, cb: 0 });
    var sign = String(x.docTypeName || x.doc_type_name || '') === 'Возврат' ? -1 : 1;
    o.goods += sign * n(x.forPay != null ? x.forPay : x.ppvz_for_pay);
    o.log += n(x.deliveryService != null ? x.deliveryService : x.delivery_rub);
    o.storage += n(x.paidStorage != null ? x.paidStorage : x.storage_fee);
    o.acc += n(x.paidAcceptance != null ? x.paidAcceptance : x.acceptance);
    o.pen += n(x.penalty);
    o.ded += n(x.deduction);
    o.add += n(x.additionalPayment != null ? x.additionalPayment : x.additional_payment);
    o.cb += n(x.cashbackAmount) + n(x.cashbackCommissionChange);
  });
  var r2 = function (v) { return Math.round(v * 100) / 100; };
  return Object.keys(by).map(function (k) {
    var o = by[k];
    ['goods', 'log', 'storage', 'acc', 'pen', 'ded', 'add', 'cb'].forEach(function (f) { o[f] = r2(o[f]); });
    o.total = r2(o.goods - o.log - o.storage - o.acc - o.pen - o.ded - o.cb);
    return o;
  }).sort(function (a, b) { return a.to < b.to ? -1 : a.to > b.to ? 1 : 0; });
}

function menuPayoutsAll() {
  var ui = SpreadsheetApp.getUi();
  var r = ui.prompt('Выплаты WB за всё время', 'С какой даты загрузить отчёты? Формат ГГГГ-ММ-ДД (например, 2025-12-01). WB хранит отчёты с 29.01.2024.', ui.ButtonSet.OK_CANCEL);
  if (r.getSelectedButton() !== ui.Button.OK) return;
  var from = String(r.getResponseText() || '').trim() || '2025-12-01';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from)) { ui.alert('Дата должна быть в формате ГГГГ-ММ-ДД, например 2025-12-01.'); return; }
  try {
    var res = syncPayouts(from);
    ui.alert('Выплаты WB', 'Еженедельных отчётов: ' + res.reports + (res.mode === 'estimate' ?
      '.\nВаш ключ «Базовый»: «Итого к оплате» посчитано по детализации и может немного отличаться от кабинета. Для точных сумм создайте ключ типа «Персональный» с категориями «Статистика» и «Финансы».' :
      '.\n«Итого к оплате» взято из WB как есть.') + '\nТеперь в приложении: «Деньги» → «WB» → «Обновить».', ui.ButtonSet.OK);
  } catch (e) { ui.alert('Ошибка: ' + e.message); }
}

function syncPayouts(fromDate) {
  ensureSheets_();
  var ss = SpreadsheetApp.getActive();
  var sheet = ss.getSheetByName(SH.pay);
  if (!sheet) { sheet = ss.insertSheet(SH.pay); sheet.setFrozenRows(1); }
  sheet.getRange('B:C').setNumberFormat('@');
  var first = !setting_('payAt');
  var from = fromDate || Utilities.formatDate(new Date(Date.now() - (first ? 90 : 42) * 86400000), TZ, 'yyyy-MM-dd');
  var to = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');
  var sum, mode = 'exact', got = 0;
  try {
    var list = [];
    for (var off = 0; off < 5000; off += 1000) {
      if (off) Utilities.sleep(61000);
      var part = wbPost_('/api/finance/v1/sales-reports/list', { dateFrom: from, dateTo: to, limit: 1000, offset: off, period: 'weekly' }) || [];
      list = list.concat(part);
      if (part.length < 1000) break;
    }
    got = list.length;
    sum = payoutListSummary(list);
  } catch (e) {
    if (e.message !== 'base') throw e;
    /* Базовый ключ: список отчётов недоступен, считаем по детализации (2 запроса в сутки) */
    var rows = [], rrd = 0;
    for (var page = 0; page < 2; page++) {
      var part2 = wbPost_('/api/finance/v1/sales-reports/detailed', { dateFrom: from, dateTo: to, limit: 100000, rrdId: rrd, period: 'weekly',
        fields: DET_FIELDS }) || [];
      if (!part2.length) break;
      rows = rows.concat(part2);
      rrd = part2[part2.length - 1].rrdId || 0;
      if (part2.length < 100000) break;
    }
    got = rows.length;
    sum = payoutSummary(rows);
    mode = 'estimate';
    try { storeFact_(factSummary(rows)); } catch (x) {}
  }
  var cur = readRows_(sheet), idx = {};
  cur.forEach(function (r, i) { idx[String(r[0])] = i; });
  sum.forEach(function (o) {
    var row = [o.id, o.from, o.to, o.goods, o.log, o.storage, o.acc, o.pen, o.ded, o.add, o.total];
    if (idx[String(o.id)] !== undefined) cur[idx[String(o.id)]] = row; else { idx[String(o.id)] = cur.length; cur.push(row); }
  });
  cur.sort(function (a, b) { return String(a[2]) < String(b[2]) ? -1 : String(a[2]) > String(b[2]) ? 1 : 0; });
  writeRows_(sheet, PAY_HEAD, cur);
  setSetting_('payAt', new Date().toISOString());
  setSetting_('payMode', mode);
  return { got: got, reports: sum.length, mode: mode };
}


/* ================= факт по товарам (детализация отчётов WB) ================= */
var DET_FIELDS = ['rrdId', 'reportId', 'dateFrom', 'dateTo', 'nmId', 'vendorCode', 'docTypeName', 'quantity', 'retailPriceWithDisc', 'forPay',
  'deliveryAmount', 'returnAmount', 'deliveryService', 'paidStorage', 'paidAcceptance', 'penalty', 'deduction', 'additionalPayment',
  'cashbackAmount', 'cashbackCommissionChange'];
var FACT_HEAD = ['№ отчёта', 'С', 'По', 'Артикул WB', 'Артикул продавца', 'Продано, шт', 'Возвраты, шт', 'Доставок', 'Отказов (возврат в пути)',
  'Выручка по цене после скидки, ₽', 'К перечислению, ₽', 'Логистика, ₽', 'Хранение, ₽', 'Приёмка, ₽', 'Штрафы, ₽'];

/** Сводит строки детализации в «отчёт × артикул». */
function factSummary(rows) {
  var by = {}, n = function (v) { var x = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(x) ? x : 0; };
  (rows || []).forEach(function (x) {
    var id = x.reportId; if (!id) return;
    var nm = Number(x.nmId) || 0, k = id + '|' + nm;
    var o = by[k] || (by[k] = { rep: id, from: String(x.dateFrom || '').slice(0, 10), to: String(x.dateTo || '').slice(0, 10), nm: nm, art: String(x.vendorCode || ''),
      sold: 0, ret: 0, dlv: 0, back: 0, rev: 0, pay: 0, log: 0, stor: 0, acc: 0, pen: 0 });
    if (!o.art && x.vendorCode) o.art = String(x.vendorCode);
    var doc = String(x.docTypeName || ''), q = n(x.quantity);
    if (doc === 'Продажа') { o.sold += q; o.rev += n(x.retailPriceWithDisc) * q; o.pay += n(x.forPay); }
    else if (doc === 'Возврат') { o.ret += q; o.rev -= n(x.retailPriceWithDisc) * q; o.pay -= n(x.forPay); }
    o.dlv += n(x.deliveryAmount); o.back += n(x.returnAmount);
    o.log += n(x.deliveryService); o.stor += n(x.paidStorage); o.acc += n(x.paidAcceptance); o.pen += n(x.penalty);
  });
  var r2 = function (v) { return Math.round(v * 100) / 100; };
  return Object.keys(by).map(function (k) { var o = by[k]; ['rev', 'pay', 'log', 'stor', 'acc', 'pen'].forEach(function (f) { o[f] = r2(o[f]); }); return o; });
}

function storeFact_(list) {
  var ss = SpreadsheetApp.getActive(), sh = ss.getSheetByName(SH.fact);
  if (!sh) { sh = ss.insertSheet(SH.fact); sh.setFrozenRows(1); }
  sh.getRange('B:C').setNumberFormat('@');
  var cur = readRows_(sh), idx = {};
  cur.forEach(function (r, i) { idx[r[0] + '|' + r[3]] = i; });
  list.forEach(function (o) {
    var row = [o.rep, o.from, o.to, o.nm || '', o.art, o.sold, o.ret, o.dlv, o.back, o.rev, o.pay, o.log, o.stor, o.acc, o.pen];
    var k = o.rep + '|' + (o.nm || '');
    if (idx[k] !== undefined) cur[idx[k]] = row; else { idx[k] = cur.length; cur.push(row); }
  });
  cur.sort(function (a, b) { return String(a[2]) < String(b[2]) ? -1 : String(a[2]) > String(b[2]) ? 1 : 0; });
  writeRows_(sh, FACT_HEAD, cur);
  setSetting_('factAt', new Date().toISOString());
  setSetting_('factErr', '');
  return list.length;
}

function syncFact(fromDate) {
  var first = !setting_('factAt');
  var from = fromDate || Utilities.formatDate(new Date(Date.now() - (first ? 120 : 42) * 86400000), TZ, 'yyyy-MM-dd');
  var to = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');
  var rows = [], rrd = 0;
  for (var page = 0; page < 3; page++) {
    if (page) Utilities.sleep(61000);
    var part = wbPost_('/api/finance/v1/sales-reports/detailed', { dateFrom: from, dateTo: to, limit: 100000, rrdId: rrd, period: 'weekly', fields: DET_FIELDS }) || [];
    if (!part.length) break;
    rows = rows.concat(part);
    rrd = part[part.length - 1].rrdId || 0;
    if (part.length < 100000) break;
  }
  return { rows: rows.length, items: storeFact_(factSummary(rows)) };
}

function menuFact() {
  var ui = SpreadsheetApp.getUi();
  try { var r = syncFact(); ui.alert('Факт по товарам', 'Строк детализации: ' + r.rows + ', записей «отчёт × артикул»: ' + r.items + '.\nВ приложении: изделие → блок «План и факт».', ui.ButtonSet.OK); }
  catch (e) {
    var msg = e.message === 'base' ? 'Ключ «Базовый»: детализацию можно запросить только 2 раза в сутки, и одну из них уже использует загрузка выплат. Факт обновится сам вместе с выплатами в 6:00.' : e.message;
    setSetting_('factErr', msg); ui.alert('Факт по товарам', msg, ui.ButtonSet.OK);
  }
}


/* ================= карточки товаров WB (контент) ================= */
function contentPost_(path, body) {
  var t = token_();
  if (!t) throw new Error('Не введён ключ WB.');
  var r = UrlFetchApp.fetch(CONTENT + path, { method: 'post', contentType: 'application/json', payload: JSON.stringify(body), headers: { Authorization: t }, muteHttpExceptions: true });
  var code = r.getResponseCode(), txt = r.getContentText() || '';
  if (code === 200) return JSON.parse(txt || '{}');
  if (code === 401 || code === 403) throw new Error('У ключа WB нет доступа к карточкам (' + code + '). Добавьте в ключ категорию «Контент» и введите его через меню «1. Ввести ключ WB».');
  if (code === 429) throw new Error('WB просит подождать (лимит запросов). Повторите через минуту.');
  throw new Error('WB ответил кодом ' + code + ': ' + txt.slice(0, 200));
}

/** Короткая выжимка карточки для приложения. */
function cardBrief(c) {
  var d = c.dimensions || {}, ph = (c.photos || [])[0] || {}, doc = ((c.documents || {}).items || [])[0] || null;
  var sku = ''; (c.sizes || []).some(function (z) { if ((z.skus || []).length) { sku = String(z.skus[0]); return true; } return false; });
  return { nm: c.nmID, art: c.vendorCode || '', brand: c.brand || '', title: c.title || '', desc: c.description || '', subj: c.subjectName || '', subjId: c.subjectID || 0,
    pack: [Number(d.length) || 0, Number(d.width) || 0, Number(d.height) || 0], kg: Number(d.weightBrutto) || 0, barcode: sku,
    chars: (c.characteristics || []).map(function (x) { return { k: String(x.name || ''), v: Array.isArray(x.value) ? x.value.join(', ') : String(x.value == null ? '' : x.value) }; }).filter(function (x) { return x.k && x.v; }),
    photo: ph.square || ph.big || ph.c516x688 || '', doc: doc ? { type: doc.type, number: doc.number || '' } : null };
}

function cardsAction(b) {
  if (b.action === 'wbPhoto') {
    var u = String(b.url || '');
    if (!/^https:\/\/[a-z0-9.-]+\.(wbbasket\.ru|wb\.ru|wbstatic\.net)\//i.test(u)) throw new Error('Неизвестный адрес фото');
    var r = UrlFetchApp.fetch(u, { muteHttpExceptions: true });
    if (r.getResponseCode() !== 200) throw new Error('WB не отдал фото (' + r.getResponseCode() + ')');
    var blob = r.getBlob();
    return { ok: true, type: blob.getContentType() || 'image/jpeg', data: Utilities.base64Encode(blob.getBytes()) };
  }
  var want = {}; (b.nms || []).forEach(function (n) { want[String(n)] = 1; });
  var out = [], cursor = { limit: 100 };
  for (var k = 0; k < 30; k++) {
    var res = contentPost_('/content/v2/get/cards/list', { settings: { sort: { ascending: true }, cursor: cursor, filter: { withPhoto: -1 } } });
    (res.cards || []).forEach(function (c) { if (!b.nms || want[String(c.nmID)]) out.push(cardBrief(c)); });
    var cur = res.cursor || {};
    if (!cur.total || cur.total < 100) break;
    cursor = { limit: 100, updatedAt: cur.updatedAt, nmID: cur.nmID };
    Utilities.sleep(700);
  }
  return { ok: true, cards: out };
}

/* ================= сборка заказов FBS ================= */
function fbsAction(b) {
  var a = b.action;
  if (a === 'fbsList') {
    var res = mpFetch_('/api/v3/orders/new', 'get');
    var orders = (res.orders || []).map(function (o) {
      return { id: o.id, at: String(o.createdAt || ''), nm: o.nmId || 0, art: o.article || '', price: Math.round(o.convertedPrice || o.price || 0) / 100,
        cargo: o.cargoType || 1, meta: o.requiredMeta || [], ddate: o.ddate || '', office: (o.offices || []).join(', ') };
    });
    var sup = [], next = 0;
    for (var k = 0; k < 10; k++) {
      var r = mpFetch_('/api/v3/supplies?limit=1000&next=' + next, 'get');
      (r.supplies || []).forEach(function (x) { if (!x.done) sup.push({ id: x.id, name: x.name || '', at: String(x.createdAt || ''), cargo: x.cargoType || 0 }); });
      if (!r.supplies || r.supplies.length < 1000 || !r.next) break;
      next = r.next;
    }
    sup.forEach(function (x) { try { x.orders = (mpFetch_('/api/marketplace/v3/supplies/' + encodeURIComponent(x.id) + '/order-ids', 'get').orderIds || []); } catch (e) { x.orders = []; } });
    return { ok: true, orders: orders, supplies: sup };
  }
  if (a === 'fbsAssemble') {
    var ids = (b.orders || []).map(Number).filter(function (x) { return x > 0; });
    if (!ids.length) throw new Error('Не выбраны заказы');
    var sid = String(b.supplyId || '');
    if (!sid) sid = mpFetch_('/api/v3/supplies', 'post', { name: String(b.name || ('Мастерская ' + Utilities.formatDate(new Date(), TZ, 'dd.MM HH:mm'))).slice(0, 128) }).id;
    if (!sid) throw new Error('WB не создал поставку');
    for (var i = 0; i < ids.length; i += 100) mpFetch_('/api/marketplace/v3/supplies/' + encodeURIComponent(sid) + '/orders', 'patch', { orders: ids.slice(i, i + 100) });
    return { ok: true, supplyId: sid, added: ids.length };
  }
  if (a === 'fbsStickers') {
    var ids2 = (b.orders || []).map(Number).filter(function (x) { return x > 0; }), out = [];
    var size = b.small ? '&width=40&height=30' : '&width=58&height=40';
    for (var j = 0; j < ids2.length; j += 100) {
      var st = mpFetch_('/api/v3/orders/stickers?type=png' + size, 'post', { orders: ids2.slice(j, j + 100) });
      (st.stickers || []).forEach(function (x) { out.push({ id: x.orderId, a: x.partA, b: x.partB, file: x.file }); });
    }
    return { ok: true, stickers: out };
  }
  if (a === 'fbsDeliver') {
    var s2 = String(b.supplyId || ''); if (!s2) throw new Error('Нет поставки');
    mpFetch_('/api/v3/supplies/' + encodeURIComponent(s2) + '/deliver', 'patch');
    var qr = {}; try { qr = mpFetch_('/api/v3/supplies/' + encodeURIComponent(s2) + '/barcode?type=png', 'get'); } catch (e) {}
    return { ok: true, supplyId: s2, qr: qr.file || '', barcode: qr.barcode || '' };
  }
  if (a === 'fbsQR') {
    var q2 = mpFetch_('/api/v3/supplies/' + encodeURIComponent(String(b.supplyId || '')) + '/barcode?type=png', 'get');
    return { ok: true, qr: q2.file || '', barcode: q2.barcode || '' };
  }
  throw new Error('Неизвестное действие');
}

/* ================= заказы FBS ================= */
var ORD_HEAD = ['ID задания', 'Создан', 'Артикул WB', 'Артикул продавца', 'Цена, ₽', 'Статус продавца', 'Статус WB', 'Обновлено'];
var FINAL_WB = { sold: 1, canceled: 1, canceled_by_client: 1, declined_by_client: 1, defect: 1, canceled_by_carrier: 1 };

function mpFetch_(path, method, body) {
  var t = token_();
  if (!t) throw new Error('Не введён ключ WB.');
  var o = { method: method || 'get', headers: { Authorization: t }, muteHttpExceptions: true };
  if (body) { o.contentType = 'application/json'; o.payload = JSON.stringify(body); }
  var r = UrlFetchApp.fetch(MP + path, o), code = r.getResponseCode(), txt = r.getContentText() || '';
  if (code >= 200 && code < 300) { try { return txt ? JSON.parse(txt) : {}; } catch (x) { return {}; } }
  var write = (method || 'get') !== 'get' && path.indexOf('/orders/status') < 0 && path.indexOf('/orders/stickers') < 0;
  if (code === 401 || code === 403) throw new Error(write ? 'Ключ WB только для чтения (' + code + '). Для сборки заказов создайте ключ с категорией «Маркетплейс» БЕЗ галочки «Только на чтение» и введите его через меню «1. Ввести ключ WB».'
    : 'У ключа WB нет доступа к заказам (' + code + '). Добавьте в ключ категорию «Маркетплейс» и введите его через меню «1. Ввести ключ WB».');
  if (code === 409) { var m409 = ''; try { m409 = JSON.parse(txt).message || ''; } catch (x) {} throw new Error('WB отказал (409)' + (m409 ? ': ' + m409 : '') + '. Проверьте заказ в кабинете WB.'); }
  if (code === 429) throw new Error('WB просит подождать (лимит запросов).');
  throw new Error('WB ответил кодом ' + code + ': ' + txt.slice(0, 200));
}

function syncOrders() {
  ensureSheets_();
  var ss = SpreadsheetApp.getActive();
  var sh = ss.getSheetByName(SH.ord);
  if (!sh) { sh = ss.insertSheet(SH.ord); sh.setFrozenRows(1); }
  sh.getRange('B:B').setNumberFormat('@'); sh.getRange('H:H').setNumberFormat('@');
  var now = Math.floor(Date.now() / 1000), from = now - 30 * 86400;
  var rows = readRows_(sh), idx = {};
  rows.forEach(function (r, i) { idx[String(r[0])] = i; });
  var next = 0, got = 0;
  for (var k = 0; k < 20; k++) {
    var res = mpFetch_('/api/v3/orders?limit=1000&next=' + next + '&dateFrom=' + from + '&dateTo=' + now, 'get');
    var list = res.orders || [];
    list.forEach(function (o) {
      var key = String(o.id), base = [o.id, String(o.createdAt || ''), o.nmId || '', o.article || '', Math.round((o.convertedPrice || o.price || 0)) / 100];
      if (idx[key] !== undefined) { var old = rows[idx[key]]; rows[idx[key]] = base.concat([old[5], old[6], old[7]]); }
      else { idx[key] = rows.length; rows.push(base.concat(['new', 'waiting', ''])); }
    });
    got += list.length;
    if (list.length < 1000 || !res.next) break;
    next = res.next;
  }
  var lim = Date.now() - 30 * 86400000;
  var open = rows.filter(function (r) { return !FINAL_WB[String(r[6])] && new Date(String(r[1])).getTime() >= lim; }).map(function (r) { return Number(r[0]); });
  for (var i = 0; i < open.length; i += 1000) {
    var st = mpFetch_('/api/v3/orders/status', 'post', { orders: open.slice(i, i + 1000) });
    (st.orders || []).forEach(function (x) {
      var j = idx[String(x.id)]; if (j === undefined) return;
      rows[j][5] = x.supplierStatus || rows[j][5]; rows[j][6] = x.wbStatus || rows[j][6]; rows[j][7] = new Date().toISOString();
    });
  }
  var keep = Date.now() - 60 * 86400000;
  rows = rows.filter(function (r) { return new Date(String(r[1])).getTime() >= keep; });
  rows.sort(function (a, b) { return String(a[1]) < String(b[1]) ? -1 : String(a[1]) > String(b[1]) ? 1 : 0; });
  writeRows_(sh, ORD_HEAD, rows);
  setSetting_('ordAt', new Date().toISOString());
  setSetting_('ordErr', '');
  return { got: got, total: rows.length };
}

function ordersEnabled_() { var st = readStateObj_(); return !!(st && st.ordCfg && st.ordCfg.on); }

function ordersRun() {
  if (!ordersEnabled_()) return;
  try { syncOrders(); }
  catch (e) {
    var prev = setting_('ordErr');
    setSetting_('ordErr', e.message);
    if (!prev) sendMail_('WB: не удаётся загрузить заказы FBS', e.message);
  }
}

function menuOrders() {
  var ui = SpreadsheetApp.getUi();
  try { ensureTrigger_(); var r = syncOrders(); ui.alert('Заказы FBS', 'Получено за 30 дней: ' + r.got + '. В листе: ' + r.total + '.', ui.ButtonSet.OK); }
  catch (e) { ui.alert('Ошибка: ' + e.message); }
}

/* ================= план печати ================= */
function cancelledBeforeShip(sup, wb) {
  sup = String(sup || ''); wb = String(wb || '');
  if (sup === 'cancel') return true;
  return (wb === 'canceled' || wb === 'declined_by_client') && (sup === 'new' || sup === 'confirm' || sup === '');
}

/** Собирает данные для планировщика из сохранённой копии приложения, листа заказов, продаж и склада. */
function planInputs(state, ordRows, salesRows, stockRows) {
  var P = state.p || {}, prods = state.products || [], applied = state.ordApplied || {}, cfg = state.ordCfg || {};
  var start = cfg.start || 0, now = Date.now(), d30 = now - 30 * 86400000;
  var match = function (nm, art) {
    nm = String(nm || ''); art = String(art || '').trim().toLowerCase();
    for (var i = 0; i < prods.length; i++) { var k = String(prods[i].sku || '').trim(); if (k && (k === nm || k.toLowerCase() === art)) return prods[i]; }
    return null;
  };
  var qty = {}, sold = {}, fromOrders = false;
  prods.forEach(function (p) { qty[p.id] = p.qty || 0; sold[p.id] = 0; });
  var haveOrders = false;
  (ordRows || []).forEach(function (r) {
    var t = new Date(String(r[1])).getTime(), p = match(r[2], r[3]); if (!p) return;
    var canc = cancelledBeforeShip(r[5], r[6]);
    if (t >= d30) { haveOrders = true; fromOrders = true; if (!canc) sold[p.id]++; }
    if (cfg.on && t >= start && !applied[String(r[0])] && !canc) qty[p.id]--;
  });
  if (!haveOrders) (salesRows || []).forEach(function (r) {
    var t = new Date(String(r[2])).getTime(); if (t < d30) return;
    var p = match(r[4], r[5]); if (!p) return;
    sold[p.id] += r[1] === 'Возврат' ? -1 : 1;
  });
  var perH = {};
  (stockRows || []).forEach(function (r) { perH[String(r[0])] = Number(r[10]) || 0; });
  var products = prods.map(function (p) {
    var buy = fromOrders ? (p.wb && p.wb.buy > 0 ? p.wb.buy : (P.buy || 1)) : 1; /* заказы × выкуп = сколько реально уходит со склада */
    return { id: p.id, name: p.name, qty: qty[p.id], min: p.min || 0, h: p.h || 0, plate: p.plate || 1, plateH: p.plateH || 0, pl: (p.rec && p.rec.pl) || [], perH: perH[p.name] || 0,
      rate: sold[p.id] > 0 ? sold[p.id] * Math.min(1, buy) / 30 : (p.plan || 0) / 30 };
  });
  var plastics = (state.plastics || []).map(function (m) { return { id: m.id, name: m.name, qty: m.qty || 0, min: m.min || 0 }; });
  return { products: products, plastics: plastics, opt: { hours: (P.printers || 1) * (P.printHours || 14), days: P.stockDays || 14 } };
}

function hm_(h) { var m = Math.round(h * 60); return Math.floor(m / 60) + ' ч ' + (m % 60 < 10 ? '0' : '') + (m % 60) + ' мин'; }

function planText(plan) {
  var L = [];
  if (!plan.items.length) L.push('Сегодня печатать ничего не нужно: запаса хватает.');
  plan.items.forEach(function (it, i) {
    L.push((i + 1) + '. ' + it.name + ' × ' + it.n + (it.per > 1 ? ' (' + it.plates + ' ст. по ' + it.per + ' шт)' : '') + ' — ' + hm_(it.hours) +
      (it.plastic.length ? ', ' + it.plastic.map(function (x) { return x.name + ' ' + x.g + ' г'; }).join(', ') : ''));
    L.push('   осталось ' + Math.round(it.qty) + ' шт' + (it.rate > 0 ? ', продаётся ~' + (Math.round(it.rate * 10) / 10) + ' в день' : ', продаж нет — до минимума') +
      (it.short ? '. Больше не позволяет ' + it.short : ''));
  });
  plan.skipped.forEach(function (x) { L.push('• Не поместилось: ' + x.name + ' (' + x.need + ' шт) — ' + x.reason); });
  plan.warn.forEach(function (w) { L.push('⚠ ' + w.name + ': после печати останется ' + w.left + ' г (минимум ' + w.min + ' г) — пора заказать'); });
  return L.join('\n');
}

function printPlanRun(force) {
  var st = readStateObj_();
  if (!st) return null;
  var cfg = st.ordCfg || {};
  if (!force && cfg.planMail === false) return null;
  if (cfg.on) { try { syncOrders(); } catch (e) {} }
  var ss = SpreadsheetApp.getActive();
  var inp = planInputs(st, readRows_(ss.getSheetByName(SH.ord)), readRows_(ss.getSheetByName(SH.sales)), readRows_(ss.getSheetByName(SH.stock)));
  var plan = planPrint(inp.products, inp.plastics, inp.opt);
  var subj = plan.items.length ? 'Печать на сегодня: ' + plan.items.length + ' изд., ' + hm_(plan.hoursUsed) : 'Печать на сегодня: запаса хватает';
  if (plan.items.length || plan.warn.length || force) sendMail_(subj, 'Принтер свободен ~' + inp.opt.hours + ' ч.\n\n' + planText(plan) +
    '\n\nПлан учитывает остатки из приложения на момент последней синхронизации и новые заказы WB.');
  return plan;
}

function menuPlan() {
  var plan = printPlanRun(true);
  SpreadsheetApp.getUi().alert(plan ? 'План отправлен.' : 'Нет данных приложения: включите синхронизацию в приложении.');
}

/* ===== Планировщик печати (одинаковый в приложении и в Google-скрипте) =====
 * products: [{id,name,qty,min,h,pl:[{id,q}],perH,rate,plate,plateH}]  rate — расход в день, perH — прибыль за час печати,
 *   plate — сколько штук помещается на стол, plateH — время печати всего стола (если пусто — h × plate)
 * plastics: [{id,name,qty,min}]
 * opt: {hours, days}  hours — сколько часов печати есть, days — на сколько дней держать запас
 */
function planPrint(products, plastics, opt) {
  var hoursLeft = opt.hours, days = opt.days || 14;
  var stockPl = {}; plastics.forEach(function (m) { stockPl[m.id] = Math.max(0, m.qty || 0); });
  var plName = {}; plastics.forEach(function (m) { plName[m.id] = m.name; });
  var cand = products.filter(function (p) { return p.h > 0; }).map(function (p) {
    var rate = p.rate > 0 ? p.rate : 0, qty = Math.max(0, p.qty || 0);
    var target = Math.max(p.min || 0, Math.ceil(rate * days));
    var need = Math.max(0, target - qty);
    var daysLeft = rate > 0 ? qty / rate : (qty < (p.min || 0) ? days : Infinity); /* без продаж — после тех, что продаются */
    return { p: p, rate: rate, qty: qty, need: need, daysLeft: daysLeft, target: target };
  }).filter(function (c) { return c.need > 0; });
  cand.sort(function (a, b) {
    var ua = Math.min(a.daysLeft, 999), ub = Math.min(b.daysLeft, 999);
    if (Math.floor(ua) !== Math.floor(ub)) return ua - ub;
    return (b.p.perH || 0) - (a.p.perH || 0);
  });
  var items = [], skipped = [];
  cand.forEach(function (c) {
    var p = c.p;
    var per = p.plate > 1 ? Math.floor(p.plate) : 1, ph = p.plateH > 0 ? p.plateH : p.h * per;
    var fresh = hoursLeft >= opt.hours - 1e-9; /* стол длиннее рабочего дня можно поставить, если день ещё пустой */
    var byTime = Math.floor(hoursLeft / ph + 1e-9);
    if (byTime < 1 && fresh && hoursLeft > 0) byTime = 1;
    if (byTime < 1) { skipped.push({ name: p.name, need: c.need, reason: per > 1 ? 'стол не помещается по времени' : 'не хватает времени' }); return; }
    var plates = Math.min(Math.ceil(c.need / per), byTime), shortPl = null;
    (p.pl || []).forEach(function (r) {
      if (!(r.q > 0)) return;
      var can = Math.floor((stockPl[r.id] || 0) / (r.q * per) + 1e-9);
      if (can < plates) { plates = can; shortPl = plName[r.id] || 'пластик'; }
    });
    if (plates <= 0) { skipped.push({ name: p.name, need: c.need, reason: 'не хватает: ' + (shortPl || 'пластик') }); return; }
    var n = plates * per;
    var used = [];
    (p.pl || []).forEach(function (r) { if (r.q > 0) { stockPl[r.id] -= r.q * n; used.push({ name: plName[r.id] || 'пластик', g: Math.round(r.q * n) }); } });
    hoursLeft = Math.max(0, hoursLeft - plates * ph);
    items.push({ id: p.id, name: p.name, n: n, plates: plates, per: per, long: ph > opt.hours, hours: Math.round(plates * ph * 100) / 100, plastic: used, qty: c.qty, rate: c.rate,
      daysLeft: c.daysLeft, perH: p.perH, short: shortPl && n < c.need ? shortPl : null, need: c.need });
  });
  var warn = [];
  plastics.forEach(function (m) {
    var left = stockPl[m.id] || 0;
    if ((m.min || 0) > 0 && left < m.min) warn.push({ name: m.name, left: Math.round(left), min: m.min });
  });
  return { items: items, skipped: skipped, warn: warn, hoursUsed: Math.round((opt.hours - hoursLeft) * 100) / 100, hours: opt.hours };
}

/* ================= резервные копии в Google Диск ================= */
var BACKUP_FOLDER = 'Мастерская 3D — резервные копии';
var BACKUP_KEEP = 12;
/** Сохраняет копию данных приложения в папку на Google Диске и удаляет самые старые (хранит 12 последних). */
function backupRun() {
  var st = readState_();
  if (!st || st.length < 10) return null;
  var it = DriveApp.getFoldersByName(BACKUP_FOLDER), folder = it.hasNext() ? it.next() : DriveApp.createFolder(BACKUP_FOLDER);
  var name = 'masterskaya-' + Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd') + '.json';
  var same = folder.getFilesByName(name); while (same.hasNext()) same.next().setTrashed(true);
  folder.createFile(name, st, 'application/json');
  var files = [], fi = folder.getFiles();
  while (fi.hasNext()) { var f = fi.next(); if (/^masterskaya-\d{4}-\d{2}-\d{2}\.json$/.test(f.getName())) files.push(f); }
  files.sort(function (a, b) { return a.getName() < b.getName() ? 1 : -1; });
  files.slice(BACKUP_KEEP).forEach(function (f) { f.setTrashed(true); });
  setSetting_('backupAt', new Date().toISOString()); setSetting_('backupErr', '');
  return { name: name, kept: Math.min(files.length, BACKUP_KEEP) };
}
function menuBackup() {
  var ui = SpreadsheetApp.getUi();
  try { var r = backupRun(); ui.alert(r ? 'Копия сохранена в Google Диск, папка «' + BACKUP_FOLDER + '»: ' + r.name + '. Хранится последних копий: ' + r.kept + '.' : 'Нет данных приложения: включите синхронизацию в приложении.'); }
  catch (e) { ui.alert('Ошибка: ' + e.message); }
}
