'use strict';
/** Фоновый обработчик запросов приложения для одного проекта (чтобы медленный WB не тормозил сервер). */
const { parentPort, workerData } = require('worker_threads');
const path = require('path');
const { loadProject, readJSON } = require('./runtime');
const { name, root, codeFile, cfgFile, schedule } = workerData;
const cfg = () => readJSON(cfgFile, {});
const proj = loadProject(name, codeFile, path.join(root, 'data', name), cfg, schedule);
parentPort.on('message', m => {
  let out;
  try {
    const r = m.kind === 'post'
      ? proj.ctx.doPost({ postData: { contents: m.body, type: 'text/plain' }, parameter: m.params || {} })
      : proj.ctx.doGet({ parameter: m.params || {} });
    out = { id: m.id, ok: true, text: r && (r.t != null ? r.t : r.getContent && r.getContent()) };
  } catch (e) { out = { id: m.id, ok: true, text: JSON.stringify({ ok: false, error: e.message }) }; }
  parentPort.postMessage(out);
});
