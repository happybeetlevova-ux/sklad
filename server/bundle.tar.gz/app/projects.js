'use strict';
/** Описание двух проектов: где код, по какому адресу API, расписание и пункты меню для страницы управления. */
module.exports = {
  master: {
    title: 'Мастерская 3D', api: '/m/exec', code: 'projects/master/Code.gs',
    schedule: [
      { fn: 'ordersRun', hourly: 5 },
      { fn: 'dailyRun', daily: '06:00' },
      { fn: 'printPlanRun', daily: '17:30' },
      { fn: 'weeklyRun', weekly: 1, at: '09:00' },
      { fn: 'monthlyRun', monthly: 3, at: '09:00' }
    ],
    actions: [
      ['Ввести ключ WB', 'menuSetToken', 'Ключ WB'],
      ['Проверить связь с WB', 'menuCheck'],
      ['Обновить тарифы', 'menuRefresh'],
      ['Загрузить продажи', 'menuSales'],
      ['Загрузить выплаты', 'menuPayouts'],
      ['Выплаты за всё время', 'menuPayoutsAll', 'С какой даты (ГГГГ-ММ-ДД)'],
      ['Загрузить заказы FBS', 'menuOrders'],
      ['Факт по товарам', 'menuFact'],
      ['Налог за прошлый месяц', 'menuTax'],
      ['Прислать план печати', 'menuPlan'],
      ['Резервная копия', 'menuBackup'],
      ['Показать ключ синхронизации', 'menuSyncKey'],
      ['Сбросить ключ синхронизации', 'menuSyncReset']
    ],
    keyProp: 'S_syncKey'
  },
  wbstat: {
    title: 'WB Аналитика', api: '/w/exec', code: 'projects/wbstat/Code.gs',
    schedule: [
      { fn: 'hourlyRun', hourly: 20 },
      { fn: 'dailyRun', daily: '05:30' }
    ],
    actions: [
      ['Ввести ключ WB', 'menuSetToken', 'Ключ WB'],
      ['Загрузить историю (90 дней)', 'menuHistory'],
      ['Обновить сейчас', 'menuRefresh'],
      ['Показать ключ доступа', 'menuShowKey'],
      ['Новый ключ доступа', 'menuResetKey'],
      ['Резервная копия', 'menuBackup']
    ],
    keyProp: 'S_appKey'
  }
};
