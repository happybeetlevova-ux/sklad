'use strict';
/**
 * Сервер «Мастерская 3D» + «WB Аналитика».
 *  - отдаёт оба приложения (папка www);
 *  - принимает запросы приложений: /m/exec и /w/exec (как веб-приложение Google);
 *  - по расписанию запускает задачи скриптов (заказы, отчёты, план печати…);
 *  - страница управления /admin (логин admin, пароль из data/config.json).
 */
const http = require('http'), fs = require('fs'), path = require('path'), cp = require('child_process'), crypto = require('crypto');
const { Worker } = require('worker_threads');
const { readJSON, atomicWrite, mkdirp, formatDate, fetchSync } = require('./runtime');
const P = require('./projects');
const ROOT = path.resolve(__dirname, '..'), DATA = mkdirp(path.join(ROOT, 'data')), WWW = path.join(ROOT, 'www');
const CFG = path.join(DATA, 'config.json'), VERSION = '1.0';
const cfg = () => readJSON(CFG, {});
const saveCfg = c => atomicWrite(CFG, JSON.stringify(c, null, 2));
if (!fs.existsSync(CFG)) saveCfg({ adminPass: crypto.randomBytes(9).toString('base64url'), port: 8080, publicUrl: '', tg: {}, updateUrl: 'https://happybeetlevova-ux.github.io/sklad/server/bundle.tar.gz' });
const log = (...a) => console.log(new Date().toISOString(), ...a);

/* ---------- обработчики запросов приложений ---------- */
const workers = {};
function worker(name) {
  if (workers[name]) return workers[name];
  const p = P[name], w = new Worker(path.join(__dirname, 'worker.js'), { workerData: { name, root: ROOT, codeFile: path.join(ROOT, p.code), cfgFile: CFG, schedule: p.schedule.map(s => s.fn) } });
  const pend = new Map(); let seq = 0;
  w.on('message', m => { const f = pend.get(m.id); if (f) { pend.delete(m.id); f(m); } });
  w.on('error', e => { log('worker', name, e.message); pend.forEach(f => f({ ok: true, text: JSON.stringify({ ok: false, error: 'Ошибка сервера: ' + e.message }) })); pend.clear(); delete workers[name]; });
  w.on('exit', () => { delete workers[name]; });
  workers[name] = { ask: msg => new Promise(res => { const id = ++seq; pend.set(id, res); w.postMessage(Object.assign({ id }, msg)); setTimeout(() => { if (pend.has(id)) { pend.delete(id); res({ ok: true, text: JSON.stringify({ ok: false, error: 'Сервер долго отвечает, попробуйте ещё раз' }) }); } }, 150000); }), w };
  return workers[name];
}

/* ---------- задачи (отдельные процессы) ---------- */
const jobs = []; let jobSeq = 0;
function runJob(name, fn, label, input, auto) {
  const running = jobs.find(j => j.project === name && j.fn === fn && !j.done);
  if (running) return running;
  const j = { id: ++jobSeq, project: name, fn, label: label || fn, started: Date.now(), done: false, auto: !!auto, msgs: [], error: '' };
  jobs.unshift(j); if (jobs.length > 60) jobs.length = 60;
  const args = [path.join(__dirname, 'runner.js'), name, fn]; if (input != null) args.push(String(input));
  const ch = cp.spawn(process.execPath, args, { cwd: ROOT, env: Object.assign({}, process.env, { TZ: 'Europe/Moscow' }) });
  let out = '', err = '';
  ch.stdout.on('data', d => out += d); ch.stderr.on('data', d => err += d);
  ch.on('close', code => {
    j.done = true; j.ended = Date.now();
    const i = out.lastIndexOf('@@RESULT@@');
    if (i >= 0) { try { const r = JSON.parse(out.slice(i + 10)); j.msgs = r.msgs || []; if (!r.ok) j.error = r.error; } catch (e) { j.error = 'Не удалось прочитать результат'; } }
    else j.error = (err || ('Процесс завершился с кодом ' + code)).slice(-500);
    log('job', name, fn, j.error ? 'ERROR ' + j.error : 'ok');
    if (j.error && auto) notify('⚠️ ' + P[name].title + ': задача «' + (label || fn) + '» не выполнилась.\n' + j.error);
  });
  return j;
}
function notify(text) {
  const tg = cfg().tg || {};
  if (!tg.token || !tg.chat) return;
  try { fetchSync('https://api.telegram.org/bot' + tg.token + '/sendMessage', { method: 'post', contentType: 'application/json', payload: JSON.stringify({ chat_id: tg.chat, text }) }, mkdirp(path.join(DATA, 'tmp'))); } catch (e) { log('tg', e.message); }
}

/* ---------- расписание (время московское) ---------- */
const SCHED = path.join(DATA, 'schedule.json');
function tick() {
  const now = process.env.M3D_NOW ? new Date(process.env.M3D_NOW) : new Date(), d = formatDate(now, 'Europe/Moscow', 'yyyy-MM-dd'), hm = formatDate(now, 'Europe/Moscow', 'HH:mm');
  const h = +hm.slice(0, 2), mi = +hm.slice(3), dow = new Date(d + 'T12:00:00Z').getUTCDay(), dom = +d.slice(8);
  const last = readJSON(SCHED, {}); let changed = false;
  Object.keys(P).forEach(name => {
    const p = P[name];
    if (!fs.existsSync(path.join(DATA, name, 'props', 'WB_TOKEN'))) return; /* пока ключ WB не введён — расписание не нужно */
    p.schedule.forEach(s => {
      let slot = null, at = null;
      if (s.hourly != null) { at = h * 60 + s.hourly; slot = d + ' ' + h; }
      else { const t = s.daily || s.at, [th, tm] = t.split(':').map(Number); at = th * 60 + tm; slot = d;
        if (s.weekly != null && dow !== s.weekly) return; if (s.monthly != null && dom !== s.monthly) return; }
      const nowM = h * 60 + mi;
      if (nowM < at || nowM - at > 40) return;
      const key = name + ':' + s.fn;
      if (last[key] === slot) return;
      last[key] = slot; changed = true;
      runJob(name, s.fn, s.fn, null, true);
    });
  });
  if (changed) atomicWrite(SCHED, JSON.stringify(last));
}

/* ---------- HTTP ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.css': 'text/css', '.txt': 'text/plain; charset=utf-8', '.ico': 'image/x-icon' };
function send(res, code, body, type, extra) { res.writeHead(code, Object.assign({ 'Content-Type': type || 'application/json; charset=utf-8', 'Cache-Control': 'no-cache' }, extra || {})); res.end(body); }
function readBody(req, max) { return new Promise((ok, no) => { let b = [], n = 0; req.on('data', c => { n += c.length; if (n > (max || 20e6)) { no(new Error('too big')); req.destroy(); } else b.push(c); }); req.on('end', () => ok(Buffer.concat(b))); req.on('error', no); }); }
function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname); if (p.endsWith('/')) p += 'index.html';
  const f = path.normalize(path.join(WWW, p));
  if (!f.startsWith(WWW)) return send(res, 403, 'forbidden', 'text/plain');
  fs.stat(f, (e, st) => {
    if (e || !st.isFile()) { if (!path.extname(p)) { res.writeHead(302, { Location: url.pathname + '/' }); return res.end(); } return send(res, 404, 'Не найдено', 'text/plain; charset=utf-8'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': /\.(html|js|webmanifest|json)$/.test(f) ? 'no-cache' : 'public, max-age=86400' });
    fs.createReadStream(f).pipe(res);
  });
}
function authOk(req) {
  const h = req.headers.authorization || '', m = h.match(/^Basic (.+)$/); if (!m) return false;
  const [u, p] = Buffer.from(m[1], 'base64').toString().split(':');
  const want = String(cfg().adminPass || ''); if (!want) return false;
  const a = Buffer.from(String(p || '')), b = Buffer.from(want);
  return u === 'admin' && a.length === b.length && crypto.timingSafeEqual(a, b);
}
const csvCell = v => { const s = v == null ? '' : String(v); return /[";\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };

async function admin(req, res, url) {
  if (!authOk(req)) return send(res, 401, 'Нужен вход', 'text/plain; charset=utf-8', { 'WWW-Authenticate': 'Basic realm="master3d", charset="UTF-8"' });
  const a = url.pathname.replace(/^\/admin\/?/, ''), q = Object.fromEntries(url.searchParams);
  const proj = P[q.project] ? q.project : null, pdir = proj ? path.join(DATA, proj) : null;
  const body = req.method === 'POST' ? JSON.parse((await readBody(req, 2e6)).toString() || '{}') : {};
  const bp = P[body.project] ? body.project : null;
  if (a === '' || a === 'index.html') return send(res, 200, fs.readFileSync(path.join(__dirname, 'admin.html')), MIME['.html']);
  if (a === 'api/state') {
    const c = cfg();
    return send(res, 200, JSON.stringify({ version: VERSION, publicUrl: c.publicUrl, tg: { token: !!(c.tg && c.tg.token), chat: c.tg && c.tg.chat || '' }, projects: Object.keys(P).map(n => {
      const dir = path.join(DATA, n), prop = k => { try { return fs.readFileSync(path.join(dir, 'props', encodeURIComponent(k)), 'utf8'); } catch (e) { return ''; } };
      const sheets = fs.existsSync(path.join(dir, 'sheets')) ? fs.readdirSync(path.join(dir, 'sheets')).filter(f => f.endsWith('.json')).map(f => decodeURIComponent(f.slice(0, -5))) : [];
      return { name: n, title: P[n].title, api: (c.publicUrl || '') + P[n].api, hasToken: !!prop('WB_TOKEN'), key: prop(P[n].keyProp), actions: P[n].actions, sheets,
        schedule: P[n].schedule.map(s => s.fn + ' — ' + (s.hourly != null ? 'каждый час в :' + String(s.hourly).padStart(2, '0') : (s.weekly != null ? 'по понедельникам ' : s.monthly != null ? s.monthly + '-го числа ' : 'каждый день ') + (s.daily || s.at))) };
    }), jobs: jobs.slice(0, 30) }));
  }
  if (a === 'api/run' && bp) { const act = P[bp].actions.find(x => x[1] === body.fn); if (!act) return send(res, 400, '{"error":"нет действия"}'); return send(res, 200, JSON.stringify(runJob(bp, body.fn, act[0], body.input))); }
  if (a === 'api/sheet' && proj) {
    const f = path.join(pdir, 'sheets', encodeURIComponent(q.name) + '.json'), rows = readJSON(f, []);
    if (q.csv) return send(res, 200, '﻿' + rows.map(r => (r || []).map(csvCell).join(';')).join('\r\n'), 'text/csv; charset=utf-8', { 'Content-Disposition': "attachment; filename*=UTF-8''" + encodeURIComponent(q.name + '.csv') });
    return send(res, 200, JSON.stringify({ total: rows.length, rows: rows.slice(0, +q.limit || 300) }));
  }
  if (a === 'api/tg') { const c = cfg(); c.tg = Object.assign({}, c.tg, { token: String(body.token || '').trim() }); if (!c.tg.token) c.tg = {}; saveCfg(c); return send(res, 200, '{"ok":true}'); }
  if (a === 'api/tgfind') {
    const c = cfg(); if (!c.tg || !c.tg.token) return send(res, 200, '{"ok":false,"error":"Сначала вставьте токен бота"}');
    try {
      const r = JSON.parse(fetchSync('https://api.telegram.org/bot' + c.tg.token + '/getUpdates', {}, mkdirp(path.join(DATA, 'tmp'))).getContentText());
      if (!r.ok) return send(res, 200, JSON.stringify({ ok: false, error: 'Telegram не принял токен: ' + (r.description || '') }));
      const m = (r.result || []).map(u => u.message || u.my_chat_member || u.channel_post).filter(Boolean).pop();
      if (!m) return send(res, 200, '{"ok":false,"error":"Напишите боту в Telegram любое сообщение (например /start) и нажмите кнопку ещё раз"}');
      c.tg.chat = String(m.chat.id); saveCfg(c); notify('✅ Сервер «Мастерская 3D» подключён. Сюда будут приходить план печати, налог и предупреждения.');
      return send(res, 200, JSON.stringify({ ok: true, chat: c.tg.chat, name: m.chat.first_name || m.chat.title || '' }));
    } catch (e) { return send(res, 200, JSON.stringify({ ok: false, error: e.message })); }
  }
  if (a === 'api/costs') {
    const costs = {}; String(body.text || '').split(/\r?\n/).forEach(l => { const m = l.trim().match(/^(\d{5,})\D+?([\d\s]+(?:[.,]\d+)?)/); if (m) costs[m[1]] = parseFloat(m[2].replace(/\s/g, '').replace(',', '.')); });
    if (!Object.keys(costs).length) return send(res, 200, '{"ok":false,"error":"Не нашёл строк вида «артикул закуп»"}');
    const key = (() => { try { return fs.readFileSync(path.join(DATA, 'wbstat', 'props', 'S_appKey'), 'utf8'); } catch (e) { return ''; } })();
    if (!key) return send(res, 200, '{"ok":false,"error":"Сначала нажмите «Показать ключ доступа» в разделе WB Аналитика"}');
    const r = await worker('wbstat').ask({ kind: 'post', body: JSON.stringify({ key, action: 'cost', costs }) });
    return send(res, 200, JSON.stringify(Object.assign(JSON.parse(r.text), { count: Object.keys(costs).length })));
  }
  if (a === 'api/files' && proj) {
    const base = path.join(pdir, 'backups'), list = [];
    const walk = (d, rel) => { if (!fs.existsSync(d)) return; fs.readdirSync(d).forEach(f => { const full = path.join(d, f), st = fs.statSync(full); if (st.isDirectory()) { if (rel) list.push({ path: path.join(rel, f), dir: true, t: st.mtimeMs }); else walk(full, f); } else list.push({ path: path.join(rel, f), size: st.size, t: st.mtimeMs }); }); };
    walk(base, '');
    const out = path.join(pdir, 'outbox.log'), tail = fs.existsSync(out) ? fs.readFileSync(out, 'utf8').slice(-6000) : '';
    return send(res, 200, JSON.stringify({ files: list.sort((x, y) => y.t - x.t), outbox: tail }));
  }
  if (a === 'api/file' && proj) {
    const f = path.normalize(path.join(pdir, 'backups', q.path || '')); if (!f.startsWith(path.join(pdir, 'backups')) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) return send(res, 404, 'нет файла', 'text/plain; charset=utf-8');
    res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': "attachment; filename*=UTF-8''" + encodeURIComponent(path.basename(f)) }); return fs.createReadStream(f).pipe(res);
  }
  if (a === 'api/export') { /* все данные сервера одним архивом */
    const tgz = path.join(DATA, 'tmp', 'export.tar.gz'); mkdirp(path.dirname(tgz));
    cp.execFileSync('tar', ['-czf', tgz, '--exclude=data/tmp', '-C', ROOT, 'data']);
    res.writeHead(200, { 'Content-Type': 'application/gzip', 'Content-Disposition': 'attachment; filename="master3d-data-' + formatDate(new Date(), 'Europe/Moscow', 'yyyy-MM-dd') + '.tar.gz"' }); return fs.createReadStream(tgz).pipe(res);
  }
  if (a === 'api/update') {
    try {
      const u = String(body.url || cfg().updateUrl || ''), tmp = mkdirp(path.join(DATA, 'tmp', 'upd')), tgz = path.join(tmp, 'b.tar.gz');
      cp.execFileSync('curl', ['-fsSL', '--max-time', '120', '-o', tgz, u]);
      const ex = mkdirp(path.join(tmp, 'x')); cp.execFileSync('tar', ['-xzf', tgz, '-C', ex]);
      if (!fs.existsSync(path.join(ex, 'app', 'server.js'))) throw new Error('В архиве нет сервера');
      ['app', 'projects', 'www'].forEach(d => { if (fs.existsSync(path.join(ex, d))) { fs.rmSync(path.join(ROOT, d + '.old'), { recursive: true, force: true }); if (fs.existsSync(path.join(ROOT, d))) fs.renameSync(path.join(ROOT, d), path.join(ROOT, d + '.old')); fs.renameSync(path.join(ex, d), path.join(ROOT, d)); } });
      fs.rmSync(tmp, { recursive: true, force: true });
      send(res, 200, '{"ok":true}'); setTimeout(() => process.exit(0), 500); return;
    } catch (e) { return send(res, 200, JSON.stringify({ ok: false, error: e.message })); }
  }
  return send(res, 404, '{"error":"нет такого адреса"}');
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const proj = Object.keys(P).find(n => url.pathname === P[n].api);
    if (proj) {
      if (req.method === 'OPTIONS') return send(res, 204, '', 'text/plain', { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST', 'Access-Control-Allow-Headers': 'Content-Type' });
      const params = Object.fromEntries(url.searchParams);
      const r = req.method === 'POST' ? await worker(proj).ask({ kind: 'post', body: (await readBody(req)).toString(), params }) : await worker(proj).ask({ kind: 'get', params });
      return send(res, 200, r.text || '{}', 'application/json; charset=utf-8', { 'Access-Control-Allow-Origin': '*' });
    }
    if (url.pathname === '/admin') { res.writeHead(302, { Location: '/admin/' }); return res.end(); }
    if (url.pathname.startsWith('/admin/')) return await admin(req, res, url);
    if (url.pathname === '/health') return send(res, 200, JSON.stringify({ ok: true, version: VERSION }));
    return serveStatic(req, res, url);
  } catch (e) { log('http', e.stack || e.message); try { send(res, 500, JSON.stringify({ ok: false, error: e.message })); } catch (x) {} }
});
const port = +process.env.PORT || cfg().port || 8080;
server.listen(port, process.env.HOST || '127.0.0.1', () => log('Сервер запущен, порт', port));
setInterval(tick, 20000); setTimeout(tick, 3000);
