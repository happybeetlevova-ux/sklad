'use strict';
/**
 * «Подмена Google» для запуска скриптов Apps Script на своём сервере.
 * Таблицы — JSON-файлы, свойства — файлы, запросы — curl, письма — Telegram, Google Диск — папка.
 * Один и тот же Code.gs работает и в Google, и здесь.
 */
const fs = require('fs'), path = require('path'), vm = require('vm'), cp = require('child_process'), crypto = require('crypto');

const enc = s => encodeURIComponent(String(s)).replace(/\*/g, '%2A');
const dec = s => decodeURIComponent(s);
function readJSON(f, d) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return d; } }
function atomicWrite(f, str) { const t = f + '.' + process.pid + '.' + Date.now() + '.tmp'; fs.writeFileSync(t, str); fs.renameSync(t, f); }
function mkdirp(d) { fs.mkdirSync(d, { recursive: true }); return d; }
function sleepMs(ms) { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, Math.max(0, ms)); }

/* ---------- даты в часовом поясе ---------- */
function formatDate(d, tz, f) {
  d = d instanceof Date ? d : new Date(d);
  const parts = {}; new Intl.DateTimeFormat('en-GB', { timeZone: tz || 'Europe/Moscow', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })
    .formatToParts(d).forEach(p => { parts[p.type] = p.value; });
  const map = { yyyy: parts.year, MM: parts.month, dd: parts.day, HH: parts.hour, mm: parts.minute, ss: parts.second };
  let out = '', i = 0;
  while (i < f.length) {
    if (f[i] === "'") { const j = f.indexOf("'", i + 1); out += f.slice(i + 1, j < 0 ? f.length : j); i = j < 0 ? f.length : j + 1; continue; }
    const t = ['yyyy', 'MM', 'dd', 'HH', 'mm', 'ss'].find(k => f.startsWith(k, i));
    if (t) { out += map[t]; i += t.length; } else { out += f[i]; i++; }
  }
  return out;
}

/* ---------- таблицы ---------- */
function makeSheet(dir, name) {
  const file = path.join(dir, enc(name) + '.json');
  let data = readJSON(file, []);
  const save = () => atomicWrite(file, JSON.stringify(data));
  const lastCol = () => { let m = 0; for (const r of data) if (r && r.length > m) m = r.length; return m; };
  const sheet = {
    getName: () => name,
    getLastRow: () => data.length,
    getLastColumn: lastCol,
    clearContents() { data = []; save(); return sheet; },
    clear() { data = []; save(); return sheet; },
    appendRow(row) { data.push(row.map(v => v instanceof Date ? v.toISOString() : v)); save(); return sheet; },
    setFrozenRows() { return sheet; }, hideSheet() { return sheet; }, showSheet() { return sheet; },
    getRange(r, c, nr, nc) {
      if (typeof r === 'string') return { setNumberFormat() { return this; }, setFontWeight() { return this; } };
      nr = nr || 1; nc = nc || 1;
      const range = {
        setValues(v) {
          for (let i = 0; i < v.length; i++) { const row = data[r - 1 + i] || (data[r - 1 + i] = []); for (let j = 0; j < v[i].length; j++) { const x = v[i][j]; row[c - 1 + j] = x instanceof Date ? x.toISOString() : x; } }
          for (let i = 0; i < data.length; i++) if (!data[i]) data[i] = [];
          save(); return range;
        },
        setValue(x) { return range.setValues([[x]]); },
        getValues() { const out = []; for (let i = 0; i < nr; i++) { const row = data[r - 1 + i] || [], o = []; for (let j = 0; j < nc; j++) { const v = row[c - 1 + j]; o.push(v === undefined || v === null ? '' : v); } out.push(o); } return out; },
        getDisplayValues() { return range.getValues().map(r2 => r2.map(String)); },
        setNumberFormat() { return range; }, setFontWeight() { return range; }
      };
      return range;
    }
  };
  return sheet;
}
function makeSpreadsheet(dir, id) {
  mkdirp(dir);
  const exists = n => fs.existsSync(path.join(dir, enc(n) + '.json'));
  return {
    getId: () => id,
    getSheetByName: n => exists(n) ? makeSheet(dir, n) : null,
    insertSheet: n => { if (!exists(n)) atomicWrite(path.join(dir, enc(n) + '.json'), '[]'); return makeSheet(dir, n); },
    getSheets: () => fs.readdirSync(dir).filter(f => f.endsWith('.json')).map(f => makeSheet(dir, dec(f.slice(0, -5))))
  };
}

/* ---------- запросы в интернет ---------- */
function fetchSync(url, o, tmpDir) {
  o = o || {};
  if (process.env.M3D_MOCK) url = process.env.M3D_MOCK + '/' + url.replace(/^https?:\/\//, ''); /* только для проверки */
  const id = crypto.randomBytes(6).toString('hex'), bodyF = path.join(tmpDir, id + '.body'), hdrF = path.join(tmpDir, id + '.hdr');
  const args = ['-sS', '--max-time', '180', '-X', String(o.method || 'get').toUpperCase(), '-o', bodyF, '-D', hdrF, '-w', '%{http_code}'];
  const headers = Object.assign({}, o.headers || {});
  if (o.contentType) headers['Content-Type'] = o.contentType;
  Object.keys(headers).forEach(k => args.push('-H', k + ': ' + headers[k]));
  let payF = null;
  if (o.payload != null) { payF = path.join(tmpDir, id + '.pay'); fs.writeFileSync(payF, typeof o.payload === 'string' ? o.payload : JSON.stringify(o.payload)); args.push('--data-binary', '@' + payF); }
  args.push(url);
  let code;
  try { code = Number(cp.execFileSync('curl', args, { stdio: ['ignore', 'pipe', 'pipe'] }).toString().trim()); }
  catch (e) { [bodyF, hdrF, payF].forEach(f => { try { f && fs.unlinkSync(f); } catch (x) {} }); throw new Error('Нет связи с ' + url.split('/')[2] + ': ' + String((e.stderr || '') + '').trim().slice(0, 160)); }
  const body = fs.existsSync(bodyF) ? fs.readFileSync(bodyF) : Buffer.alloc(0), hdr = fs.existsSync(hdrF) ? fs.readFileSync(hdrF, 'utf8') : '';
  [bodyF, hdrF, payF].forEach(f => { try { f && fs.unlinkSync(f); } catch (x) {} });
  const ct = ((hdr.match(/^content-type:\s*([^\r\n;]+)/gim) || []).pop() || '').replace(/^content-type:\s*/i, '');
  return {
    getResponseCode: () => code,
    getContentText: () => body.toString('utf8'),
    getBlob: () => ({ getBytes: () => Array.from(body), getContentType: () => ct, getDataAsString: () => body.toString('utf8') }),
    getHeaders: () => ({ 'Content-Type': ct })
  };
}

/* ---------- Telegram ---------- */
function telegram(cfg, text, tmpDir) {
  const tg = (cfg() || {}).tg || {};
  if (!tg.token || !tg.chat) return false;
  const chunks = []; let s = String(text); while (s.length) { chunks.push(s.slice(0, 3900)); s = s.slice(3900); }
  for (const c of chunks) {
    const r = fetchSync('https://api.telegram.org/bot' + tg.token + '/sendMessage', { method: 'post', contentType: 'application/json', payload: JSON.stringify({ chat_id: tg.chat, text: c, disable_web_page_preview: true }) }, tmpDir);
    if (r.getResponseCode() !== 200) throw new Error('Telegram не принял сообщение: ' + r.getContentText().slice(0, 160));
  }
  return true;
}

/**
 * Загружает проект (Code.gs) с данными в dataDir. cfg — функция, возвращающая настройки сервера.
 * Возвращает { ctx, call(fn, args, input) } — вызов функции скрипта с перехватом окон меню.
 */
function loadProject(name, codeFile, dataDir, cfg, scheduleNames) {
  mkdirp(dataDir); const tmpDir = mkdirp(path.join(dataDir, 'tmp')), propDir = mkdirp(path.join(dataDir, 'props')), sheetDir = path.join(dataDir, 'sheets');
  const backupDir = mkdirp(path.join(dataDir, 'backups')), outbox = path.join(dataDir, 'outbox.log');
  let ui = { msgs: [], input: null };
  const props = {
    getProperty: k => { try { return fs.readFileSync(path.join(propDir, enc(k)), 'utf8'); } catch (e) { return null; } },
    setProperty: (k, v) => { atomicWrite(path.join(propDir, enc(k)), String(v)); return props; },
    deleteProperty: k => { try { fs.unlinkSync(path.join(propDir, enc(k))); } catch (e) {} return props; },
    getProperties: () => { const o = {}; fs.readdirSync(propDir).forEach(f => { if (!f.endsWith('.tmp')) o[dec(f)] = fs.readFileSync(path.join(propDir, f), 'utf8'); }); return o; }
  };
  const iter = list => { let i = 0; return { hasNext: () => i < list.length, next: () => list[i++] }; };
  const fileObj = (dir, n) => ({ getName: () => n, setTrashed(v) { if (v) fs.rmSync(path.join(dir, n), { recursive: true, force: true }); }, getId: () => path.join(dir, n) });
  const folderObj = dir => ({
    getName: () => path.basename(dir),
    createFile: (n, content) => { atomicWrite(path.join(dir, n), String(content)); return fileObj(dir, n); },
    getFilesByName: n => iter(fs.existsSync(path.join(dir, n)) ? [fileObj(dir, n)] : []),
    getFiles: () => iter(fs.readdirSync(dir).filter(f => !f.endsWith('.tmp')).map(f => fileObj(dir, f)))
  });
  const btn = { OK: 'OK', CANCEL: 'CANCEL', YES: 'YES', NO: 'NO', CLOSE: 'CLOSE' };
  const uiObj = {
    ButtonSet: { OK: 'OK', OK_CANCEL: 'OK_CANCEL', YES_NO: 'YES_NO' }, Button: btn,
    alert(a, b) { ui.msgs.push(b === undefined || typeof b !== 'string' ? String(a) : String(a) + '\n' + String(b)); return btn.OK; },
    prompt(title, text) { const v = ui.input; return { getSelectedButton: () => v == null ? btn.CANCEL : btn.OK, getResponseText: () => v == null ? '' : String(v) }; },
    createMenu() { const m = { addItem: () => m, addSeparator: () => m, addToUi: () => m, addSubMenu: () => m }; return m; }
  };
  const ctx = {
    console, JSON, Math, Date, Number, String, Array, Object, RegExp, Error, isFinite, isNaN, parseFloat, parseInt, encodeURIComponent, decodeURIComponent,
    SpreadsheetApp: { getActive: () => makeSpreadsheet(sheetDir, name), getActiveSpreadsheet: () => makeSpreadsheet(sheetDir, name), getUi: () => uiObj },
    PropertiesService: { getScriptProperties: () => props },
    UrlFetchApp: { fetch: (url, o) => fetchSync(url, o, tmpDir) },
    Utilities: {
      sleep: sleepMs, formatDate, getUuid: () => crypto.randomUUID(),
      base64Encode: b => Buffer.from(Array.isArray(b) ? b : String(b)).toString('base64'),
      base64DecodeWebSafe: s => Array.from(Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64')),
      newBlob: b => ({ getDataAsString: () => Buffer.from(Array.isArray(b) ? b : String(b)).toString('utf8'), getBytes: () => Array.isArray(b) ? b : Array.from(Buffer.from(String(b))) })
    },
    LockService: { getScriptLock: () => {
      const dir = path.join(dataDir, 'lock'); let held = false;
      return {
        waitLock(ms) {
          const end = Date.now() + (ms || 30000);
          for (;;) {
            try { fs.mkdirSync(dir); held = true; return; } catch (e) {
              try { if (Date.now() - fs.statSync(dir).mtimeMs > 120000) { fs.rmSync(dir, { recursive: true, force: true }); continue; } } catch (x) {}
              if (Date.now() > end) throw new Error('Сервер занят, попробуйте ещё раз'); sleepMs(50);
            }
          }
        },
        tryLock(ms) { try { this.waitLock(ms); return true; } catch (e) { return false; } },
        releaseLock() { if (held) { try { fs.rmdirSync(dir); } catch (e) {} held = false; } }
      };
    } },
    ScriptApp: {
      getProjectTriggers: () => (scheduleNames || []).map(h => ({ getHandlerFunction: () => h })),
      newTrigger: () => { const b = new Proxy({}, { get: (t, k) => k === 'create' ? () => ({}) : () => b }); return b; },
      deleteTrigger() {}, WeekDay: { MONDAY: 1, TUESDAY: 2, WEDNESDAY: 3, THURSDAY: 4, FRIDAY: 5, SATURDAY: 6, SUNDAY: 0 },
      getService: () => ({ getUrl: () => ((cfg() || {}).publicUrl || '') + (name === 'master' ? '/m/exec' : '/w/exec') })
    },
    ContentService: { createTextOutput: t => ({ t, getContent: () => t, setMimeType() { return this; } }), MimeType: { JSON: 'json', TEXT: 'text' } },
    Session: { getEffectiveUser: () => ({ getEmail: () => 'telegram' }), getActiveUser: () => ({ getEmail: () => 'telegram' }) },
    MailApp: { sendEmail: (to, subject, body) => {
      let sent = false;
      try { sent = telegram(cfg, '📬 ' + subject + '\n\n' + body, tmpDir); } catch (e) { fs.appendFileSync(outbox, new Date().toISOString() + ' ОШИБКА TELEGRAM: ' + e.message + '\n'); }
      fs.appendFileSync(outbox, new Date().toISOString() + (sent ? ' → Telegram' : ' (не отправлено: Telegram не настроен)') + '\n' + subject + '\n' + body + '\n\n');
    }, getRemainingDailyQuota: () => 100 },
    DriveApp: {
      getFoldersByName: n => iter(fs.existsSync(path.join(backupDir, n)) ? [folderObj(path.join(backupDir, n))] : []),
      createFolder: n => folderObj(mkdirp(path.join(backupDir, n))),
      getFileById: id => ({ makeCopy: (n, folder) => { const dst = path.join(backupDir, folder.getName(), n); mkdirp(dst); fs.cpSync(sheetDir, dst, { recursive: true }); return fileObj(path.dirname(dst), n); } })
    }
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(codeFile, 'utf8'), ctx, { filename: codeFile });
  return {
    ctx, name, dataDir, props,
    call(fn, args, input) {
      ui = { msgs: [], input: input == null ? null : input };
      if (typeof ctx[fn] !== 'function') throw new Error('Нет функции ' + fn);
      const result = ctx[fn].apply(null, args || []);
      return { result, msgs: ui.msgs };
    }
  };
}

module.exports = { loadProject, formatDate, fetchSync, telegram, readJSON, atomicWrite, mkdirp, sleepMs };
