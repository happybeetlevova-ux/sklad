'use strict';
/** Запуск одной функции скрипта отдельным процессом: node runner.js <проект> <функция> [ввод] */
const path = require('path');
const { loadProject, readJSON } = require('./runtime');
const P = require('./projects');
const root = path.resolve(__dirname, '..'), [name, fn, input] = process.argv.slice(2);
const cfgFile = path.join(root, 'data', 'config.json');
let out;
try {
  const p = P[name]; if (!p) throw new Error('Нет проекта ' + name);
  const proj = loadProject(name, path.join(root, p.code), path.join(root, 'data', name), () => readJSON(cfgFile, {}), p.schedule.map(s => s.fn));
  const r = proj.call(fn, [], input === undefined ? null : input);
  out = { ok: true, msgs: r.msgs, result: r.result === undefined ? null : r.result };
} catch (e) { out = { ok: false, error: e.message, msgs: [] }; }
process.stdout.write('\n@@RESULT@@' + JSON.stringify(out));
